function [sim_Image_binning,sim_cuti_high_binning,sim_wavelet_binning,sim_waveletfilt_binning,sim_Diffconstwavelet_binning,sim_Cxval_binning,sim_Cyval_binning,sim_Int7_binning,sim_Int13_7ring_binning,sim_kymograph_binning,sim_kymographdIdr_binning,sim_radiusFWHM_binning,sim_Diffconst_binning,sim_Diffconstpatch_binning,sim_Result_binning,sim_Positionx_binning,sim_Positiony_binning,sim_Direction_binning] = diffusion2dSimulation(xPSF,Diffconst,pxsize)
% DIFFUSION2DSIMULATION simulate events and average for statistics
% In order to be able to judge the quality of the analysis method designed
% within the analysisGUIs, images are simulated here and analysed via GUI.

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

% exposure time of 1 ms simulated and averaged to 10 ms, set intensity of
% single event to 1/10 of the intensity in a 10 ms frame.
o = waitbar(0,'simulating data...');
for i=1:10
    waitbar(i / 10)
    [Image,Positionx,Positiony,Direction] = diffusion2d(xPSF,4,450,0.001,Diffconst,pxsize);
    sim2_Image(:,:,:,i)=Image;
    sim2_Positionx(:,:,i)=Positionx;
    sim2_Positiony(:,:,i)=Positiony;
    sim2_Direction(:,:,i)=Direction;
end
close(o)

ind=1;
for j=6:10:446
    sim_Image_binning(:,:,ind,:)=mean(sim2_Image(:,:,j:j+9,:),3);
    sim_Positionx_binning(ind,:,:)=sim2_Positionx(j+4,:,:);
    sim_Positiony_binning(ind,:,:)=sim2_Positiony(j+4,:,:);
    sim_Direction_binning(ind,:,:)=atan((sim2_Positiony(j+4,:,:)-sim2_Positiony(j-5,:,:))./(sim2_Positionx(j+4,:,:)-sim2_Positionx(j-5,:,:)));
    ind=ind+1;
end
sim_Image_binning=cat(3,sim2_Image(:,:,1:5,:),sim_Image_binning);

sim_Result_binning=zeros(4,size(sim_Image_binning,4));
sim_Result_binning(2,:)=ceil(size(sim_Image_binning,1)/2);
sim_Result_binning(3,:)=ceil(size(sim_Image_binning,2)/2);
sim_Result_binning(4,:)=1:1:size(sim_Image_binning,4);

%% only analyze stable events, where the averaged intensity doesn't drop
[sim_kymograph_binning,sim_kymographdIdr_binning,sim_radiusFWHM_binning,sim_Diffconst_binning,sim_Diffconstpatch_binning,sim_cuti_high_binning,sim_inti_high_binning,sim_wavelet_binning,sim_waveletfilt_binning,sim_Diffconstwavelet_binning,sim_Cxval_binning,sim_Cyval_binning,sim_Int7_binning,sim_Int13_7ring_binning] = radialkymograph_sim2(sim_Result_binning,sim_Image_binning,13,pxsize);

lowbo=0.7;
cuti_Int=squeeze(sum(sum(sim_cuti_high_binning)));
for i=1:size(cuti_Int,2)
   minval=min(cuti_Int(:,i));
   cuti_Int(:,i)=cuti_Int(:,i)-minval;
end
Intini=mean(cuti_Int(6:8,:));
cuti_Int_stable=cuti_Int;
k=1;
l=1;
ind_nonstable=[];
ind_stable=[];
for i=1:size(cuti_Int,2)
    for j=1:10
        if cuti_Int(5+j,i)<Intini(i).*lowbo
            ind_nonstable(k)=i; %remember event number to be discarded
            k=k+1;
            break
        elseif cuti_Int(5+j,i)>Intini(i).*lowbo && j==10
            ind_stable(l)=i;
            l=l+1;
        end
    end
end

[sim_kymograph_binning,sim_kymographdIdr_binning,sim_radiusFWHM_binning,sim_Diffconst_binning,sim_Diffconstpatch_binning,sim_cuti_high_binning,sim_inti_high_binning,sim_wavelet_binning,sim_waveletfilt_binning,sim_Diffconstwavelet_binning,sim_Cxval_binning,sim_Cyval_binning,sim_Int7_binning,sim_Int13_7ring_binning] = radialkymograph_sim2(sim_Result_binning(:,ind_stable),sim_Image_binning,13,pxsize);

end

