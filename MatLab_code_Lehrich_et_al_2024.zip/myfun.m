function [dif]=myfun(x,length,ydata)
% MYFUN input function for gauss-fit

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

F=zeros(length,length);
for i=1:length
    for j=1:length
        F(i,j)=(x(4)*exp(-((((i-x(3)).^2)+(j-x(2)).^2))/(2*x(1).^2)))+x(5);
    end
end
dif=F-ydata;
end