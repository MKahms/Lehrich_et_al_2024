function [dif]=myfunrational(x,length,ydata)
% MYFUNRATIONAL input function for fit of rational function

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

F=zeros(length,1);
for i=1:length
    F(i)=((x(1)-x(2))/((1+(x(5).*exp((i-x(4)).*(x(3))))).^x(6))) + x(2); 
end
dif=F-ydata;
end