function [DiffIm,avgbefore,avgafter] = counthistreadin(stimvec,avgbefore,avgafter,stimframedel,stimframeshift,dirname,fname,calcdirname)                                                                                                           
% COUNTHISTREADIN reads in data for further processing in function 
% counthist

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

[A]=imreadtiff2(dirname,fname,calcdirname);


if stimframedel==1      %stimulation frame is not taken into account
    stimframe=stimvec+1+stimframeshift; %with the rolling shutter of the
                        %Orca camera, the stimulation trigger number n
                        %occurs in frame n+1
    stimframebefore=stimframe-avgbefore; %first frame for averaging,
                        %according to the number of frames to be averaged
                        %prestim (avgbefore) 
    stimframeafter=stimframe+avgafter; %last frame for averaging, according
                        %to the number of frames to be averaged poststim
                        %(avgafter)
                        
    Abefore=zeros(size(A,1),size(A,2),numel(stimframe));
    Aafter=zeros(size(A,1),size(A,2),numel(stimframe));
    for i=1:numel(stimframe)
        Abefore(:,:,i)=sum(A(:,:,stimframebefore(i):stimframe(i)-1),3)/avgbefore;
        Aafter(:,:,i)=sum(A(:,:,stimframe(i)+1:stimframeafter(i)),3)/avgafter;
        %average frames after stimulation (including stimulation frame)
    end
end
if stimframedel==0      %stimulation frame is taken into account
    stimframe=stimvec+1+stimframeshift;
    stimframebefore=stimframe-avgbefore; 
    stimframeafter=stimframe+avgafter;
    
    Abefore=zeros(size(A,1),size(A,2),numel(stimframe));
    Aafter=zeros(size(A,1),size(A,2),numel(stimframe));
    for i=1:numel(stimframe)
        Abefore(:,:,i)=sum(A(:,:,stimframebefore(i):stimframe(i)-1),3)/avgbefore;
        Aafter(:,:,i)=sum(A(:,:,stimframe(i):stimframeafter(i)-1),3)/avgafter;
        %average frames after stimulation (including stimulation frame)
    end
end    
DiffIm=Aafter-Abefore; %difference image

assignin('base','stimframedel',stimframedel);
assignin('base','stimframeshift',stimframeshift);

end

