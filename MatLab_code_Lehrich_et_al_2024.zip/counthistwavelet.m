function [Resultsort]=counthistwavelet(xPSF,DiffIm,CutIsize,IntEvent,DN2photon,threshtemplate)
% COUNTHISTWAVELET performs � trous wavelet filtering of the
% background-subtracted difference images DiffIm, as well as peak-finding,
% image segmentation and peak-fitting of events in DiffIm

% xPSF          specific PSF parameters calculated for each camera by
%               fitting a Gaussian function to measured beads
% DiffIm        difference image used to determine localizations of fusion
%               events. DiffIm is calculated as the difference between e.g.
%               five frames before and two frames after the stimulation
%               pulse
% CutIsize      size of the cutout region for image segmentation
% IntEvent      threshold for wavelet filtered images to select events
% DN2photon     camera-specific photon conversion factor
% threshtemplate    threshold for template matching algorithm
% Resultsort    matrix containing the intensities (1st row),
%               x-positions (2nd row), y-positions (3rd row) and frame
%               number in the difference image DiffIm, or number of
%               stimulation pulse (4th row).

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

%% pre-allocation of empty matrices and generation of templates
[Tsub11,Tsub55,Template]=create_Tsubs7(0.1,0.02,xPSF,CutIsize);
EVektor=ones(1,10);
del=[]; 
cutl=floor(CutIsize/2);
counts=double.empty(1,0);
Lsg1SubSub=double.empty(1,0);
Lsg2SubSub=double.empty(1,0);
xstart=double.empty(0,3);
val=double.empty(1,0);
ind=double.empty(1,0);

%% � trous wavelet filtering and image segmentation
[P,~,~,~] = atrouswavelet(DiffIm);
z=zeros(size(P,1),size(P,2),size(P,3));
z(P>IntEvent)=1;
Z=bwconncomp(z,4);
clear z

%% template matching algorithm
if numel(Z.PixelIdxList)>=1
    h = waitbar(0,'Please wait...');
for i=1:numel(Z.PixelIdxList)
    waitbar(i / numel(Z.PixelIdxList))
    [val(i),ind(i)]=max(P(Z.PixelIdxList{i}));
    [xstart(i,1), xstart(i,2), xstart(i,3)]=ind2sub(size(P),Z.PixelIdxList{i}(ind(i)));
    if (xstart(i,1)-cutl)>1 && (xstart(i,1)+cutl)<(size(P(:,:,xstart(i,3)),1)-1) && (xstart(i,2)-cutl)>1 && (xstart(i,2)+cutl)<(size(P(:,:,xstart(i,3)),2)-1)
        [~,~,lsg1SubSub,lsg2SubSub]=MakeTemp8_templ(EVektor,Template,DiffIm(:,:,xstart(i,3)),Tsub11,Tsub55,xstart(i,2),xstart(i,1),del,CutIsize,threshtemplate);
        if numel(lsg1SubSub)>0
            Lsg1SubSub(i)=lsg1SubSub;
            Lsg2SubSub(i)=lsg2SubSub; 
            if Lsg1SubSub(i)>(cutl+1) && Lsg2SubSub(i)>(cutl+1) && Lsg1SubSub(i)<(size(P,2)-cutl) && Lsg2SubSub(i)<(size(P,1)-cutl)
                counts(i)=sum(sum(DiffIm(round(Lsg2SubSub(i))-cutl:round(Lsg2SubSub(i))+cutl,round(Lsg1SubSub(i))-cutl:round(Lsg1SubSub(i))+cutl,xstart(i,3))));
                    if counts(i)<=0
                        counts(i)=0;
                        Lsg1SubSub(i)=0;
                        Lsg2SubSub(i)=0;
                        xstart(i,:)=0;
                    end
            else 
                Lsg1SubSub(i)=0;
                Lsg2SubSub(i)=0;
                counts(i)=0;
                xstart(i,:)=0;
            end
        else
            Lsg1SubSub(i)=0;
            Lsg2SubSub(i)=0;
            counts(i)=0;
            xstart(i,:)=0;
        end
    else
        Lsg1SubSub(i)=0;
        Lsg2SubSub(i)=0;
        counts(i)=0;
        xstart(i,:)=0;
    end
end
close(h)
Result(1,:)=counts.*DN2photon;
Result(2,:)=Lsg1SubSub;
Result(3,:)=Lsg2SubSub;
Result(4,:)=xstart(:,3);
else
    Result=double.empty(4,0);
end

%% sorting of Result matrix
Resultsort=sortrows(Result')';
index=find(Resultsort(1,:)>0,1,'first'); %find the first nonzero element
Resultsort=Resultsort(:,index:end);