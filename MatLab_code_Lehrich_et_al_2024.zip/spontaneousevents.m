function [UNIdist,distframe,NumcnsctvEvnt,eventnumcnsctv,Resultblinkingsort,mublblinking,sigmablblinking,Resultspontaneous] = spontaneousevents(Result,pxsize)
% SPONTANEOUSEVENTS finds the number and length of spontaneous events

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

distmax=200./pxsize;
Shiftx=gallery('circul',Result(2,:));
a=Shiftx(1,:);
b=Shiftx(2:end,:);
c=cat(1,b,a);
shiftx=flipdim(c,1);
clear a b c Shiftx

Shifty=gallery('circul',Result(3,:));
a=Shifty(1,:);
b=Shifty(2:end,:);
c=cat(1,b,a);
shifty=flipdim(c,1);
clear a b c Shifty

clear a b c Shiftframe
check=gallery('circul',(1:size(Result,2)));
a=check(1,:);
b=check(2:end,:);
c=cat(1,b,a);
d=flipdim(c,1);
check=d;
clear a b c d

Staticx=repmat(Result(2,:),size(Result,2),1);
Staticy=repmat(Result(3,:),size(Result,2),1);
dist=sqrt((Staticx - shiftx).^2 + (Staticy - shifty).^2);

dist(dist<=distmax)=1;
dist(dist>distmax)=0;

distframe=dist.*check;

UNIdist=cell.empty(1,0);
unidist=[];
a=1;
b=0;
k=1;

distframe2=distframe;
u = waitbar(0,'spontaneousevents calculating...');
while k<=size(distframe2,2)
    waitbar(k / size(distframe2,2))
    unidist=cat(2,unidist,unique(distframe2(:,k)));
    for j=size(distframe2,2):-1:(k+1)
        if numel(intersect(unidist,distframe2(:,j)))>=2
            unidist=unique(union(unidist,distframe2(:,j)));
            distframe2(:,j)=[];
            b=b+1;
        end
    end
        if b>0
            unidist(unidist==0)=[];
            UNIdist{a}=unidist';
            a=a+1;
        end
        unidist=[];
        k=k+1;
end
close(u)
for l=1:size(UNIdist,2)
UNIdist{l}(2,:)=Result(1,UNIdist{l}(1,:));
UNIdist{l}(3,:)=Result(2,UNIdist{l}(1,:)); 
UNIdist{l}(4,:)=Result(3,UNIdist{l}(1,:));
UNIdist{l}(5,:)=Result(4,UNIdist{l}(1,:));
end

%% find events in consecutive frames
NumcnsctvEvnt=[];
eventnumcnsctv=double.empty(1,0);
Resultspontaneous=double.empty(4,0);
Resultblinking=Result;
for h=1:numel(UNIdist)
    UNI=(sortrows(UNIdist{h}',5))';
    q=diff(UNI(5,:));
    r=find([q inf]>1);
    s=diff([0 r]);
    NumcnsctvEvnt=cat(2,NumcnsctvEvnt,s);
    nominate=[];
    findvec=find(q<=1);
    for i=1:length(findvec)
        nominate=unique(cat(2,nominate,findvec(i),findvec(i)+1));
    end
    eventnumcnsctv{h}=UNI(1,nominate);
    Resultspontaneous=cat(2,Resultspontaneous,Resultblinking(:,eventnumcnsctv{h}));
    Resultblinking(:,eventnumcnsctv{h})=NaN;
end
Resultblinking=reshape(Resultblinking,1,numel(Resultblinking));
Resultblinking(isnan(Resultblinking)==1)=[];
Resultblinking=reshape(Resultblinking,4,(numel(Resultblinking)/4));
Resultblinking=sortrows(Resultblinking')';
Resultspontaneous=sortrows(Resultspontaneous')';
index=find(Resultblinking(1,:)>0,1,'first');
Resultblinkingsort=Resultblinking(:,index:end);
[mublblinking,sigmablblinking]=normfit(Resultblinkingsort(1,:));

%% find spontaneous events out of 'close proximity'-events
%find out at which position events occur after a certain set frame, e.g.
%frame 154
nonsyn=[];
for i=1:numel(UNIdist)
a=find(UNIdist{i}(5,1)>=154); %everything appearing for the first time after 154 is not synchronous
    if numel(a)==1
        nonsyn=cat(2,nonsyn,i);
    end
end
end