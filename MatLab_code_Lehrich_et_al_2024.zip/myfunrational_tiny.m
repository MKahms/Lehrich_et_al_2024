function [dif]=myfunrational_tiny(x,length,ydata)
% MYFUNRATIONAL_TINY input function for fit of rational function

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

F=zeros(length,1);
for i=1:length
    F(i)=((x(1)-x(3))/(1+exp((i-x(2))))) + x(3);
end
dif=F-ydata;
end