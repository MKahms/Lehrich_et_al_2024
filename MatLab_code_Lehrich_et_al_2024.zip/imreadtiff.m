function [A,fname,dirname,w]=imreadtiff

% IMREADTIFF read in of a stack of images. The data path is selected
% manually from a dropdown men, which shows up upon function execution

% A             Image stack 
% fname         name of the data stack on the harddrive
% dirname       name of the directory, where the data stack is located
% w             name of the current directory, where the MatLab functions
%               are located

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

%% read-in of image stack
w=cd;
[fname,dirname] = uigetfile('*.tif');
tic
cd(dirname);
info = imfinfo(fname);
num_images = numel(info);
A=zeros(info(1,1).Height,info(1,1).Width,num_images,'double');%'uint16');
h = waitbar(0,'reading images...');
for k = 1:num_images
waitbar(k / num_images)
  A(:,:,k) = imread(fname,k,'Info', info);  

end
close(h)
cd(w);

toc
