function [Tsubcentr,Tsub11,Tsub55,Template]=create_Tsubs7_3(accuracy1,accuracy2,xPSF,CutIsize) %here: 0.02 or 0.1
% CREATE_TSUBS7_3 finds the brightest peak, which doesn't have to be the 
% central peak of a gaussian distribution. create_Tsubs7_2 is an improved 
% version of create_Tsubs7. Here, an additional round of template fitting 
% is implemented, where first the central pixel is searched.

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

x02=CutIsize/2;
y02=CutIsize/2;

if CutIsize>4
    rim=(CutIsize/2)-((CutIsize-4)/2)+1; 
    %central pixel is supposed to be at integer pixel, not inbetween
    
    accuracy0=1; %shift by whole pixel
    Tsubcentr=zeros(CutIsize,CutIsize,(CutIsize-4)*(CutIsize-4));
    lauf=0;
    for h = 1:(CutIsize-4)
    for k = 1:(CutIsize-4)
    for j = 1:CutIsize
        for i=1:CutIsize
            Tsubcentr(i,j,lauf+k)=(xPSF(4)*exp(-((((i-(rim-accuracy0+h*accuracy0)).^2)+(j-(rim-accuracy0+k*accuracy0)).^2))/(2*xPSF(1).^2)))+xPSF(5);
        end                                              
    end
    Tsubcentr(:,:,lauf+k)=mat2gray(Tsubcentr(:,:,lauf+k));
    end
    lauf=lauf+k; 
    end

end

Tsub11 = zeros(CutIsize,CutIsize,((1/accuracy1)+3)*((1/accuracy1)+3));
lauf=0;
for h = 1:(1.3/accuracy1) 
  for k = 1:(1.3/accuracy1) 
    for j = 1:CutIsize
        for i=1:CutIsize
            Tsub11(i,j,lauf+k)=(xPSF(4)*exp(-((((i-(x02-2.*accuracy1+h*accuracy1)).^2)+(j-(y02-2.*accuracy1+k*accuracy1)).^2))/(2*xPSF(1).^2)))+xPSF(5);
        end
    end
    Tsub11(:,:,lauf+k)=mat2gray(Tsub11(:,:,lauf+k));
  
  end
lauf=lauf+k; 
end


Tsub55 = zeros(CutIsize,CutIsize,((((1.4/accuracy2)+1) * (((1.4/accuracy2)+1)))));
lauf=0;
for h = 1:(1.4/accuracy2)+1
  for k = 1:(1.4/accuracy2)+1
    for j = 1:CutIsize
        for i=1:CutIsize
            Tsub55(i,j,lauf+k)=(xPSF(4)*exp(-((((i-(x02-accuracy1-(6.*accuracy2)+h*accuracy2)).^2)+(j-(y02-accuracy1-(6.*accuracy2)+k*accuracy2)).^2))/(2*xPSF(1).^2)))+xPSF(5);        
        end
    end
    Tsub55(:,:,lauf+k)=mat2gray(Tsub55(:,:,lauf+k));
  
  end
lauf=lauf+k; 
end


Tsub = zeros(CutIsize,CutIsize,((1/accuracy1)+1)*((1/accuracy1)+1));
lauf=0;
for h = 1:(1.1/accuracy1) 
  for k = 1:(1.1/accuracy1) 
    for j = 1:CutIsize
        for i=1:CutIsize
            Tsub(i,j,lauf+k)=(xPSF(4)*exp(-((i-(x02-accuracy1+h*accuracy1)).^2+(j-(y02-accuracy1+k*accuracy1)).^2)/(2*xPSF(1).^2)))+xPSF(5);
        end
    end
    Tsub(:,:,lauf+k)=mat2gray(Tsub(:,:,lauf+k));
  
  end
lauf=lauf+k; 
end

Template=zeros(CutIsize,CutIsize);
for i = 1:CutIsize
    for j=1:CutIsize
        Template(i,j) = Tsub(i,j,61);
    end
end

end