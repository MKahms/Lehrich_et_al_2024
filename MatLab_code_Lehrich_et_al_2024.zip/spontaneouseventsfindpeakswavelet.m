function [Resultsort, mubaselineevents, sigmabaselineevents] = spontaneouseventsfindpeakswavelet(A,xPSF,baselineframes,CutIsize,DN2photon,IntEvent,threshtemplate,voltage)
% SPONTANEOUSEVENTSFINDPEAKS find spontaneous events in baseline

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

%% set up variables
del=[];
EVektor=ones(1,10);
cutl=floor(CutIsize/2);
counts=double.empty(1,0);
Lsg1SubSub=double.empty(1,0);
Lsg2SubSub=double.empty(1,0);
Lsg1=double.empty(1,0);
Lsg2=double.empty(1,0);
xstart=double.empty(1,0);
val=double.empty(1,0);
ind=double.empty(1,0);
[Tsub11,Tsub55,Template]=create_Tsubs7(0.1,0.02,xPSF,CutIsize);

%% subtract background in baseline and calculate wavelet filtered images
Abg=median(A(:,:,baselineframes),3);
AbgcorSignal=bsxfun(@minus,A(:,:,baselineframes),Abg);
[~,P23] = atrouswavelet(AbgcorSignal);

%% calculate intensity of found events (= events above the wavelet filter)
z=zeros(size(P23,1),size(P23,2),size(P23,3));
z(P23>(IntEvent))=1; 
Z=bwconncomp(z,8);
s = waitbar(0,'computing fit...');
for i=numel(Z.PixelIdxList):-1:1
    waitbar(i / numel(Z.PixelIdxList))
    [val(i),ind(i)]=max(P23(Z.PixelIdxList{i}));
    [xstart(i,1), xstart(i,2), xstart(i,3)]=ind2sub(size(P23),Z.PixelIdxList{i}(ind(i)));
    counts(i)=0;
    Lsg1SubSub(i)=0;
    Lsg2SubSub(i)=0;
    if (xstart(i,1)-cutl)>1 && (xstart(i,1)+cutl)<(size(AbgcorSignal(:,:,xstart(i,3)),1)-1) && (xstart(i,2)-cutl)>1 && (xstart(i,2)+cutl)<(size(AbgcorSignal(:,:,xstart(i,3)),2)-1);
        [lsg1,lsg2,lsg1SubSub,lsg2SubSub]=MakeTemp8_templ(EVektor,Template,AbgcorSignal(:,:,xstart(i,3)),Tsub11,Tsub55,xstart(i,2),xstart(i,1),del,CutIsize,threshtemplate);
        if numel(lsg1SubSub)>0
            Lsg1(i)=lsg1;
            Lsg2(i)=lsg2;
            Lsg1SubSub(i)=lsg1SubSub;
            Lsg2SubSub(i)=lsg2SubSub;
            if Lsg1SubSub(i)>(cutl+1) && Lsg2SubSub(i)>(cutl+1) && Lsg1SubSub(i)<(size(AbgcorSignal,2)-cutl) && Lsg2SubSub(i)<(size(AbgcorSignal,1)-cutl)
                counts(i)=sum(sum(AbgcorSignal(round(Lsg2SubSub(i))-cutl:round(Lsg2SubSub(i))+cutl,round(Lsg1SubSub(i))-cutl:round(Lsg1SubSub(i))+cutl,xstart(i,3))));
                    if counts(i)<=0
                        counts(i)=[];
                        Lsg1SubSub(i)=[];
                        Lsg2SubSub(i)=[];
                        xstart(i,:)=[];
                    end
            else
                counts(i)=[];
                Lsg1SubSub(i)=[];
                Lsg2SubSub(i)=[];
                xstart(i,:)=[];
            end
        else
            counts(i)=[];
            Lsg1SubSub(i)=[];
            Lsg2SubSub(i)=[];
            xstart(i,:)=[];
        end
    else
        counts(i)=[];
        Lsg1SubSub(i)=[];
        Lsg2SubSub(i)=[];
        xstart(i,:)=[];
    end
end
close(s)
Result(1,:)=((counts.*DN2photon)./voltage).*10;
Result(2,:)=Lsg1SubSub;
Result(3,:)=Lsg2SubSub;
Result(4,:)=xstart(:,3);

Resultsort=sortrows(Result')';
index=find(Resultsort(1,:)>0,1,'first');
Resultsort=Resultsort(:,index:end);
[mubaselineevents,sigmabaselineevents]=normfit(Resultsort(1,:));

end

