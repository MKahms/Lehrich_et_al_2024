function []=APALManalysis_final(xPSF,DN2photon,pxsize,CutIsize,CutIsizeGUI,CutIsizeGUI2,avgbefore,avgafter,stimframedel,stimframeshift,voltage,Mean_SNR,threshtemplate,calcdirname,stimlength,stimvec,baselineframes,pHluorins)

% APALMANALYSIS_FINAL performs single molecule detection followed by
% diffusion analysis of detected events on a series of microscopy images.

% xPSF              vector containing fitting parameter for the PSF of the
%                   imaging system (see function myfun.m)
% DN2photon         camera-specific conversion factor transforming digital
%                   numbers (counts) into photon numbers, 
%                   DN2photon = 0.6794 for the Hamamatsu Orca Flash4 V2
% pxsize            pixel size of the camera, pxsize = 65nm for the
%                   Hamamatsu Orca Flash4 V2 and an 100x objective.
% CutIsize          size of the subregion to be analyzed, CutIsize = 9 for 
%                   the Hamamatsu Orca Flash4 V2
% CutIsizeGUI       size of the subregion to be analyzed with the first 
%                   order GUI, CutIsizeGUI = 13 for the Hamamatsu Orca 
%                   Flash4 V2
% CutIsizeGUI2      size of the subregion to be analyzed with the second 
%                   order GUI, CutIsizeGUI = 9 for the Hamamatsu Orca
%                   Flash4 V2
% avgbefore         number of frames to be averaged before the stimulus for 
%                   the sliding window background subtraction, here
%                   avgbefore = 5
% avgafter          number of frames to be averaged after the stimulus for 
%                   the sliding window background subtraction, here
%                   avgafter = 2
% stimframedel      stimulation frame can either be taken into account
%                   (stimframedel = 0) or not taken into account
%                   (stimframedel = 1)
% stimframeshift    shift of stimulation frame; stimframeshift = 1 for the
%                   Hamamatsu Orca Flash4 V2, since the stimulation trigger
%                   number n occurs in frame n+1 in rolling shutter mode
% voltage           voltage used to modulate laser power, maximum is 10 V  
% Mean_SNR          signal-to-noise ratio threshold for image filtering
% threshtemplate    threshold for template matching algorithm
% calcdirname       name of the directory containing Matlab code
% stimlength        number of frames between two stimuli
% stimvec           vector containing frame numbers where stimulation
%                   occurs
% baselineframes    vector containing all baseline frames
% pHluorins         number of pHluorin copies per cargo protein, can either
%                   be '1' or '2'.

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024


%% read in image
[A,fname,dirname]=imreadtiff;
framesstim=stimlength;

%% baseline analysis
[Resultsort] = spontaneouseventsfindpeakswavelet(A,xPSF,baselineframes,CutIsize,DN2photon,Mean_SNR,threshtemplate,voltage);
[~,~,~,~,Resultblinking,mublblinking,sigmablblinking,~] = spontaneousevents(Resultsort(:,1:10:end),pxsize);
clear A %reduce workspace

%% Positions and intensity of events in stimulation frames
[Resultsorthigh,Resultsortlow,~,~]=pHluorinhistogram(Resultblinking,sigmablblinking,stimvec,xPSF,Mean_SNR,DN2photon,mublblinking,CutIsize,threshtemplate,dirname,fname,calcdirname,voltage,avgbefore,avgafter,stimframedel,stimframeshift,pHluorins);

%% Diffusion analysis of averaged, summed up events
[Astim] = diffusionanalysisreadin(stimvec,avgbefore,framesstim,stimframedel,stimframeshift,dirname,fname,calcdirname);

%% analysis of stable events only
% only analyze stable events, where the averaged intensity doesn't drop
% below a certain value (e.g. 70%) within a region of 13x13 pixel
[~,~,~,~,~,cuti_high,~,~,~,~,~,~,~,~,~,~,~,~,~,~] = radialkymograph(Resultsorthigh,Astim,CutIsizeGUI,pxsize,xPSF);
lowbo=0.7;
cuti_Int=squeeze(sum(sum(cuti_high)));
for i=1:size(cuti_Int,2)
   minval=min(cuti_Int(:,i));
   cuti_Int(:,i)=cuti_Int(:,i)-minval;
end
Intini=mean(cuti_Int(6:8,:));
k=1;
l=1;
ind_nonstable=[];
ind_stable=[];
for i=1:size(cuti_Int,2)
    for j=1:10
        if cuti_Int(5+j,i)<Intini(i)*lowbo
            ind_nonstable(k)=i; %remember event number to be discarded
            k=k+1;
            break
        elseif cuti_Int(5+j,i)>Intini(i)*lowbo && j==10
            ind_stable(l)=i;
            l=l+1;
        end
    end
end

%% Diffusion analysis of single events (radial kymograph analysis)
% only analyze stable events
[kymograph, kymographdIdr, radiusFWHM, Diffconst, Diffconstpatch, cuti_high, inti_high, wavelet, waveletfilt, Diffconstwavelet, Cxval, Cyval, Int5, Int7, Int9_5ring, Int13_7ring, numpx5, numpx7, numpx9_5ring, numpx13_7ring] = radialkymograph(Resultsorthigh(:,ind_stable),Astim,CutIsizeGUI,pxsize,xPSF);
for i=numel(Diffconst):-1:1
    if Diffconst(i) < 0
        kymograph(:,:,i)=[];
        kymographdIdr(:,:,i)=[];
        radiusFWHM(:,:,i)=[];
        Diffconst(i)=[];
        Diffconstpatch(i)=[];
        cuti_high(:,:,:,i)=[];
        inti_high(:,i)=[];
        wavelet(:,:,:,i)=[];
        waveletfilt(:,:,:,i)=[];
        Diffconstwavelet(i)=[];
        Cxval(:,i)=[];
        Cyval(:,i)=[];
        Int5(:,i)=[];
        Int7(:,i)=[];
        Int9_5ring(:,i)=[];
    end
end
GUIanalyseevents=[];
GUIanalyseeventsmat=[];
GUIdiscardevents=[];
GUIdiscardeventsmat=[];

assignin('base','cuti_high',cuti_high);
assignin('base','wavelet',wavelet);
assignin('base','waveletfilt',waveletfilt);
assignin('base','Diffconstwavelet',Diffconstwavelet);
assignin('base','Cxval',Cxval);
assignin('base','Cyval',Cyval);
assignin('base','Int7',Int7);
assignin('base','Int13_7ring',Int13_7ring);
assignin('base','kymograph',kymograph);
assignin('base','radiusFWHM',radiusFWHM);
assignin('base','Diffconst',Diffconst);
assignin('base','Diffconstpatch',Diffconstpatch);
assignin('base','Resultsorthigh',Resultsorthigh);
assignin('base','Diffconstwavelet',Diffconstwavelet);

guide;
% select analysisGUI for 13x13 px cutout (orca),
% selection rules:
% annular intensity ratio   - discard too fast events and cutouts with
%                             neighboring events (fast decrease of ratio signal)
% annular intensity         - central ring should not decrease rapidly
%                             (doughnut-shaped signal), outer signal should
%                             not increase rapidly (neighboring event)
% kymograph                 - gradual increase from central to outer
%                             pixels, no sudden signal increase in center
%                             (blinking?) or rim (neighboring event)
% half-max radius in kym    - smooth increase

% Events 'to be discarded' are not necessarily discarded, but undergo a
% second round of analysis. Images discarded in the first round of analysis
% have to be cut out again, with a smaller size:

GUIanalyseevents=evalin('base','GUIanalyseevents',GUIanalyseevents);
GUIdiscardevents=evalin('base','GUIdiscardevents',GUIdiscardevents);

if isempty(GUIanalyseevents)==0
    for i=1:size(GUIanalyseevents,1)
        GUIanalyseeventsmat(i,1)=str2double(GUIanalyseevents(i));
    end
else
    GUIanalyseeventsmat=[];
end
if isempty(GUIdiscardevents)==0
    for i=1:size(GUIdiscardevents,1)
        GUIdiscardeventsmat(i,1)=str2double(GUIdiscardevents(i));
    end
else
    GUIdiscardeventsmat=[];
end

if isempty(GUIdiscardevents)==0
[small_kymograph, small_kymographdIdr, small_radiusFWHM, small_Diffconst, small_Diffconstpatch, small_cuti_high,~, small_wavelet, small_waveletfilt, small_Diffconstwavelet, small_Cxval, small_Cyval,~, small_Int5, small_Int7,~, small_Int9_5ring,~,~,~,~,~] = radialkymograph_small(Resultsorthigh,Astim,CutIsizeGUI2,pxsize);
% only use stable small cutout regions
small_cuti_high=small_cuti_high(:,:,:,GUIdiscardeventsmat);
lowbo=0.7;
small_cuti_Int=squeeze(sum(sum(small_cuti_high)));
for i=1:size(small_cuti_Int,2)
    minval=min(small_cuti_Int(:,i));
    small_cuti_Int(:,i)=small_cuti_Int(:,i)-minval;
end
small_Intini=mean(small_cuti_Int(6:8,:));
small_cuti_Int_stable=small_cuti_Int;
k=1;
l=1;
small_ind_nonstable=[];
small_ind_stable=[];
for i=1:size(small_cuti_Int,2)
    for j=1:10
        if small_cuti_Int(5+j,i)<small_Intini(i)*lowbo
            small_ind_nonstable(k)=i; %remember event number to be discarded
            k=k+1;
        break
        elseif small_cuti_Int(5+j,i)>small_Intini(i)*lowbo && j==10
        small_ind_stable(l)=i;
        l=l+1;
        end
    end
end
small_ind_analyse=GUIdiscardeventsmat(small_ind_stable);

%%
small_cuti_high=small_cuti_high(:,:,:,small_ind_stable);
small_wavelet=small_wavelet(:,:,:,small_ind_analyse);
small_waveletfilt=small_waveletfilt(:,:,:,small_ind_analyse);
small_Diffconstwavelet=small_Diffconstwavelet(:,small_ind_analyse);
small_Cxval=small_Cxval(:,small_ind_analyse);
small_Cyval=small_Cyval(:,small_ind_analyse);
small_Int5=small_Int5(:,small_ind_analyse);
small_Int7=small_Int7(:,small_ind_analyse);
small_Int9_5ring=small_Int9_5ring(:,small_ind_analyse);
small_kymograph=small_kymograph(:,:,small_ind_analyse);
small_kymographdIdr=small_kymographdIdr(:,:,small_ind_analyse);
small_radiusFWHM=small_radiusFWHM(:,:,small_ind_analyse);
small_Diffconst=small_Diffconst(:,small_ind_analyse);
small_Diffconstpatch=small_Diffconstpatch(:,small_ind_analyse);

assignin('base','pxsize',pxsize);
assignin('base','small_cuti_high',small_cuti_high);
assignin('base','small_wavelet',small_wavelet);
assignin('base','small_waveletfilt',small_waveletfilt);
assignin('base','small_Diffconstwavelet',small_Diffconstwavelet);
assignin('base','small_Cxval',small_Cxval);
assignin('base','small_Cyval',small_Cyval);
assignin('base','small_Int5',small_Int5);
assignin('base','small_Int9_5ring',small_Int9_5ring);
assignin('base','small_kymograph',small_kymograph);
assignin('base','small_radiusFWHM',small_radiusFWHM);
assignin('base','small_Diffconst',small_Diffconst);
assignin('base','small_Diffconstpatch',small_Diffconstpatch);
assignin('base','Resultsorthigh',Resultsorthigh);
assignin('base','small_Diffconstwavelet',small_Diffconstwavelet);

small_GUIanalyseevents=[];
small_GUIanalyseeventsmat=[];
small_GUIdiscardevents=[];
small_GUIdiscardeventsmat=[];

guide;
% select analysisGUI_small for 9x9 px cutout (orca),

%Then start the second round of analysis with analysisGUIsmall.m. After the second round of analysis, write all
%events to be analyzed into one matrix:

small_GUIanalyseevents=evalin('base','small_GUIanalyseevents',small_GUIanalyseevents);
small_GUIdiscardevents=evalin('base','small_GUIdiscardevents',small_GUIdiscardevents);
if numel(small_GUIanalyseevents)>0
    for i=1:size(small_GUIanalyseevents,1)
        small_GUIanalyseeventsmat(i,1)=str2double(small_GUIanalyseevents(i));
    end
end
if numel(small_GUIdiscardevents)>0
    for i=1:size(small_GUIdiscardevents,1)
        small_GUIdiscardeventsmat(i,1)=str2double(small_GUIdiscardevents(i));
    end
    GUIdiscardeventsmat_all=sort(GUIdiscardeventsmat(small_GUIdiscardeventsmat));
else
    GUIdiscardeventsmat_all=sort(GUIdiscardeventsmat);
end
Diffconst_analyse=Diffconst(GUIanalyseeventsmat);
Diffconst_analyse_small=small_Diffconst(small_GUIanalyseeventsmat);
Diffconst_analyse_all=cat(2,Diffconst_analyse_small,Diffconst_analyse);
Diffconst_discard_all=Diffconst(GUIdiscardeventsmat_all);
GUIanalyseeventsmat_all=sort(cat(1,GUIanalyseeventsmat,GUIdiscardeventsmat(small_GUIanalyseeventsmat)));
else
    GUIdiscardeventsmat_all=sort(GUIdiscardeventsmat);
    Diffconst_analyse=Diffconst(GUIanalyseeventsmat);
    Diffconst_analyse_all=Diffconst_analyse;
    Diffconst_discard_all=Diffconst(GUIdiscardeventsmat_all);
    GUIanalyseeventsmat_all=GUIanalyseeventsmat;
end

%average diffusion constant:
Diffconst_analyse_all_avg=median(Diffconst_analyse_all);
%as well as the patch diffusion:
Diffconst_analyse_patch=Diffconstpatch(GUIanalyseeventsmat_all);
Diffconst_analyse_patch_avg=median(Diffconstpatch(GUIanalyseeventsmat_all));

%% For the averaging analysis, only take those events which also were analysed with the GUI:
GUI_cuti_high=cuti_high(:,:,:,GUIanalyseeventsmat_all);
lngth=round((size(GUI_cuti_high,1)-CutIsize)./2);
cutiavg=mat2gray(sum(GUI_cuti_high((lngth+1):(lngth+CutIsize),(lngth+1):(lngth+CutIsize),1:26,:),4));
oldopts=optimset('lsqcurvefit');
options=optimset(oldopts,'display','off','MaxIter',10000,'MaxFunEvals',10000,'algorithm','levenberg-marquardt');
x0start=xPSF;
X_avg=zeros(size(cutiavg,3),length(x0start));
for i=1:size(cutiavg,3)
[x_avg]=lsqnonlin(@myfun,x0start,[],[],options,CutIsize,cutiavg(:,:,i));
X_avg(i,:)=x_avg;
end
stdsnm_avg=X_avg(:,1)*pxsize; 
stdsnm_avg2=stdsnm_avg(6:end);
stdsnm_avg2=cat(1,xPSF(1).*pxsize,stdsnm_avg2); %let all plots go through origin
aavg=polyfit(0:10:100,(2.*((stdsnm_avg2(1:11))./1000).^2)',1);
Diffconstavg_GUI=(1000.*aavg(1))/4;

%% averaging analysis of low-intensity events:
cuti_low=zeros(CutIsizeGUI,CutIsizeGUI,framesstim,size(Resultsortlow,2));
inti_low=zeros(framesstim,size(Resultsortlow,2));
for i=1:size(Resultsortlow,2)
    if Resultsortlow(3,i)>=floor(CutIsizeGUI/2) && Resultsortlow(3,i)<=(size(Astim,2)-floor(CutIsizeGUI/2)) && Resultsortlow(2,i)>=floor(CutIsizeGUI/2) && Resultsortlow(2,i)<=(size(Astim,2)-floor(CutIsizeGUI/2))
        cuti_low(:,:,:,i)=Astim(round(Resultsortlow(3,i))-(floor(CutIsizeGUI/2)):round(Resultsortlow(3,i))+(floor(CutIsizeGUI/2)),round(Resultsortlow(2,i))-(floor(CutIsizeGUI/2)):round(Resultsortlow(2,i))+(floor(CutIsizeGUI/2)),:,Resultsortlow(4,i));
        inti_low(:,i)=sum(sum(cuti_low(:,:,:,i)));
    end
end

lowbo=0.7;
cuti_Int_low=squeeze(sum(sum(cuti_low)));
for i=1:size(cuti_Int_low,2)
   minval=min(cuti_Int_low(:,i));
   cuti_Int_low(:,i)=cuti_Int_low(:,i)-minval;
end
Intini_low=mean(cuti_Int_low(6:8,:));
cuti_Int_low_stable=cuti_Int_low;
k=1;
l=1;
ind_low_nonstable=[];
ind_low_stable=[];
for i=1:size(cuti_Int_low,2)
    for j=1:10
        if cuti_Int_low(5+j,i)<Intini_low(i)*lowbo
            ind_low_nonstable(k)=i; %remember event number to be discarded
            k=k+1;
            break
        elseif cuti_Int_low(5+j,i)>Intini_low(i)*lowbo && j==10
            ind_low_stable(l)=i;
            l=l+1;
        end
    end
end
cuti_low_analy=cuti_low(:,:,:,ind_low_stable);

cutiavg_low_stable=mat2gray(sum(cuti_low_analy((lngth+1):(lngth+CutIsize),(lngth+1):(lngth+CutIsize),1:26,:),4));
oldopts=optimset('lsqcurvefit');
options=optimset(oldopts,'display','off','MaxIter',10000,'MaxFunEvals',10000,'algorithm','levenberg-marquardt');
x0start=xPSF;
X_avg_low_stable=zeros(size(cutiavg_low_stable,3),length(x0start));
for i=1:size(cutiavg_low_stable,3)
[x_avg_low_stable]=lsqnonlin(@myfun,x0start,[],[],options,CutIsize,cutiavg_low_stable(:,:,i));
X_avg_low_stable(i,:)=x_avg_low_stable;
end
stdsnm_avg_low_stable=X_avg_low_stable(:,1)*pxsize; 
stdsnm_avg2_low_stable=stdsnm_avg_low_stable(6:end);
stdsnm_avg2_low_stable=cat(1,xPSF(1).*pxsize,stdsnm_avg2_low_stable); %let all plots go through origin
aavg_low_stable=polyfit(0:10:100,(2.*((stdsnm_avg2_low_stable(1:11))./1000).^2)',1);
Diffconstavg_low_stable=(1000.*aavg_low_stable(1))/4;

cutiavg_low=mat2gray(sum(cuti_low((lngth+1):(lngth+CutIsize),(lngth+1):(lngth+CutIsize),1:26,:),4));
oldopts=optimset('lsqcurvefit');
options=optimset(oldopts,'display','off','MaxIter',10000,'MaxFunEvals',10000,'algorithm','levenberg-marquardt');
x0start=xPSF;
X_avg_low=zeros(size(cutiavg_low,3),length(x0start));
for i=1:size(cutiavg_low,3)
[x_avg_low]=lsqnonlin(@myfun,x0start,[],[],options,CutIsize,cutiavg_low(:,:,i));
X_avg_low(i,:)=x_avg_low;
end
stdsnm_avg_low=X_avg_low(:,1)*pxsize; 
stdsnm_avg2_low=stdsnm_avg_low(6:end);
stdsnm_avg2_low=cat(1,xPSF(1).*pxsize,stdsnm_avg2_low); %let all plots go through origin
aavg_low=polyfit(0:10:100,(2.*((stdsnm_avg2_low(1:11))./1000).^2)',1);
Diffconstavg_low=(1000.*aavg_low(1))/4;

%% save file
clear Astim Avec
filename=strcat(dirname,'20210119_analysisSNR',mat2str(Mean_SNR),'.mat');
save(filename)

end