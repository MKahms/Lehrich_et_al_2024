function [Resultsorthigh,Resultsortlow,Resultsort,DiffIm] = pHluorinhistogram(Resultblinking,sigmak,stimvec,xPSF,Mean_SNR12,DN2photon,mublblinking,CutIsize,threshtemplate,dirname,fname,calcdirname,voltage,avgbefore,avgafter,stimframedel,stimframeshift,pHluorins)
% PHLUORINHISTOGRAM generate histogram of pHluorin measurement

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

%%
% for cargo proteins with two copies of pHluorin:
stringcompare=strcmp('2',pHluorins);
    if stringcompare==1
        lowbo=mublblinking.*2;
        highbo=mublblinking.*4;
    end
% for cargo proteins with one copy of pHluorin:
stringcompare=strcmp('1',pHluorins);
    if stringcompare==1
        lowbo=mublblinking;
        highbo=mublblinking.*2;
        lowbomin=mublblinking.*0.5;
        lowbomax=mublblinking.*1.5;
    end

%% read in stimulation frames
[DiffIm] = counthistreadin(stimvec,avgbefore,avgafter,stimframedel,stimframeshift,dirname,fname,calcdirname);
[Resultsort]=counthistwavelet(xPSF,DiffIm,CutIsize,Mean_SNR12,DN2photon,threshtemplate);
Resultsort(1,:)=(Resultsort(1,:)./voltage).*10;

[DiffIm_zeropeak] = counthistreadin((stimvec-3),avgbefore,avgafter,stimframedel,stimframeshift,dirname,fname,calcdirname);
cutl=floor(CutIsize/2);
counts_zeropeak=zeros(1,numel(Resultsort(1,:))); %Resultsort from counthistwavelet.m
for i=1:numel(Resultsort(1,:))
	counts_zeropeak(i)=sum(sum(DiffIm_zeropeak(round(Resultsort(3,i))-cutl:round(Resultsort(3,i))+cutl,round(Resultsort(2,i))-cutl:round(Resultsort(2,i))+cutl,Resultsort(4,i))));
end

min(min(counts_zeropeak*DN2photon));
max(max(counts_zeropeak*DN2photon));
[muzero,sigmazero]=normfit(counts_zeropeak*DN2photon,-250:50:400);

k = 1;
sigmaq = sqrt((sigmak^2 - sigmazero^2)/k); 
for k = 1:11
	sigmak(k) = sqrt(sigmazero^2 + (k-1) * sigmaq^2);
end

%% plot stimulation frames' intensity
minbo=50.*(floor((min(Resultsort(1,:))./50)));
maxbo=100.*(ceil((max(Resultsort(1,:))./100)));
[countshist,binshist]=hist(Resultsort(1,:),minbo:50:maxbo);

minbobl=50.*(floor((min(Resultblinking(1,:))./50)));
maxbobl=100.*(ceil((max(Resultblinking(1,:))./100)));
[countsbl,binsbl]=hist(Resultblinking(1,:),minbobl:50:maxbobl);

figure, stairs(binshist,countshist,'LineWidth',2,'Color',[216/255 41/255 0/255]);
hold on
stairs(binsbl,countsbl,'LineWidth',2,'Color',[212/255 208/255 200/255]);
set(gca,'box','off','fontsize',10,'fontweight','b','FontName','Arial');
xlabel('Intensity (photons)','fontsize',10,'fontweight','b','FontName','Arial');
ylabel('# release events','fontsize',10,'fontweight','b','FontName','Arial');
xmax=max(binshist);
ymax=round(10*ceil(max(countshist)/10));
ytick=10;
IntpHluorin=round(mublblinking);
line([lowbo lowbo],[0 ymax],'LineWidth',2,'Color',[0/255 153/255 255/255]);
line([highbo highbo],[0 ymax],'LineWidth',2,'Color',[0/255 153/255 255/255]);
ax1_pos = get(gca,'Position');
ax2 = axes('Position',ax1_pos,'XAxisLocation','top','YAxisLocation','left','Color','none','XTick',(0:(IntpHluorin/xmax):xmax),'XTickLabel',(0:1:(xmax/IntpHluorin)),'YTick',(0:ytick:ymax),'YTickLabel',(0:ytick:ymax));
set(gca,'box','off','fontsize',10,'fontweight','b','FontName','Arial');
xlabel('# pHluorins','fontsize',10,'fontweight','b','FontName','Arial');

indhigh=find(Resultsort(1,:)>=highbo,1,'first');
Resultsorthigh=Resultsort(:,indhigh:end);
indlow=find(Resultsort(1,:)>=lowbo,1,'first');
Resultsortlow=Resultsort(:,1:indlow);

end

