function [Lsg1,Lsg2,Lsg1SubSub,Lsg2SubSub]=MakeTemp8_templ_3b(Template,Image,Tsubcentr,Tsub11,Tsub55,guessx,guessy,del,CutIsize)
% MAKETEMP8_TEMPL_3b is the template matching algorithm, which compares a
% stack of templates with the measured PSF of a fluorophore to find its
% localization. The templates are shifted by sub-pixel distances to yield
% sub-pixel localization precision

% Template      experimentally derived PSF
% Image         original image containing fluorophore signal to be
%               localized
% Tsubcentr     stack of templates shifted by whole pixels
% Tsub11        stack of templates with large shift distance
% Tsub55        stack of templates with small shift distance
% guessx        starting point for localization procedure in x ('guessed'
%               position)
% guessy        starting point for localization procedure in y ('guessed'
%               position)
% del           events to be deleted
% CutIsize      size of the cutout region for image segmentation
% Lsg1, Lsg2    localization coordinates from first set of templates Tsub11
% Lsg1SubSub, Lsg2SubSub
%               localization coordinates from second set of templates
%               Tsub55

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

[x,y] = size(Image);
[x2,y2] = size(Template);

EVektor=ones(1,11);
cutl=fix(CutIsize/2);
numObj=numel(guessx);
Lsg1=zeros(1,numObj);
Lsg2=zeros(1,numObj);
Lsg1SubSub=zeros(1,numObj);
Lsg2SubSub=zeros(1,numObj);
if numObj>=1
    for k = 1 : numObj
        a=guessx(k);
        b=guessy(k);
        CutI=Image((b-cutl):(b+cutl),(a-cutl):(a+cutl));
        CutI=mat2gray(CutI); 
        Sub0 = sum(sum(bsxfun(@minus,Tsubcentr,CutI).^2)); 
        Sub0 = shiftdim(Sub0);
        [Val0,Ind0]=min(Sub0);
        
        n=sqrt(size(Tsubcentr,3));
        
        a=a+((Ind0)-(fix((Ind0)/n)*n))-ceil(n/2);
        b=b+((ceil((Ind0)/n)))-ceil(n/2);
        
        if b-cutl>0 && b+cutl<size(Image,1) && a-cutl>0 && a+cutl<size(Image,2)
            CutI=Image((b-cutl):(b+cutl),(a-cutl):(a+cutl)); 
        end
        CutI=mat2gray(CutI);
        
        Sub = sum(sum(bsxfun(@minus,Tsub11,CutI).^2)); 
        Sub = shiftdim(Sub);
        [Val,Ind]=min(Sub);
   
        Lsg1(k)=a-0.6+((Ind-1)-(fix((Ind-1)/13)*13))*0.1;
        Lsg2(k)=b-0.6+((fix((Ind-1)/13))*0.1);

        solve=((((fix((Ind-1)/13)))*71*5)+(((((Ind-1)/13)-(floor(((Ind-1)/13))))*13))*5);
        m=1:11;
        t5=(solve+m)'*EVektor+71*(EVektor'*m-1);
        Tsubsub=Tsub55(:,:,t5);                                             
    
        Sub2 = sum(sum(bsxfun(@minus,Tsubsub,CutI).^2)); 
        Sub2 = shiftdim(Sub2);
        [Val2,Ind2]=min(Sub2);
                                                                
        Lsg1SubSub(k)=a-0.6+((Ind-1)-(fix((Ind-1)/13)*13))*0.1 - 0.1 +((Ind2-1)-(fix((Ind2-1)/11)*11))*0.02;
        Lsg2SubSub(k)=b-0.6+((fix((Ind-1)/13))*0.1) - 0.1 +((fix((Ind2-1)/11))*0.02);
    end

end
Lsg1(Lsg1 == 0) = [];
Lsg2(Lsg2 == 0) = [];
Lsg1SubSub(Lsg1SubSub == 0) = [];
Lsg2SubSub(Lsg2SubSub == 0) = [];
n=numel(del);
end

