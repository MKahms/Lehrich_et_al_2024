function [dif]=myfunrational_small(x,length,ydata)
% MYFUNRATIONAL_SMALL input function for fit of rational function

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

F=zeros(length,1);
for i=1:length
    F(i)=((x(1)-x(4))/(1+exp((i-x(2)).*(x(3))))) + x(4);
end
dif=F-ydata;
end