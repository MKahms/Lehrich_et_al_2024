function [P2] = atrouswavelet_GUI(Image)
%ATROUSWAVELET apply a trous wavelet on single image

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

atrouskernel1=[1/16, 1/4, 3/8, 1/4, 1/16];
atrouskernel2=[1/16, 0, 1/4, 0, 3/8, 0, 1/4, 0, 1/16];
atrouskernel3=[1/16, 0, 0, 0, 1/4, 0, 0, 0, 3/8, 0, 0, 0, 1/4, 0, 0, 0, 1/16];

kernel1=atrouskernel1'*atrouskernel1;
kernelimage1 = zeros(size(Image,1),size(Image,2));
kernelimage1(1:length(atrouskernel1),1:length(atrouskernel1)) = kernel1;
fftkernel1 = fft2(kernelimage1);

kernel2=atrouskernel2'*atrouskernel2;
kernelimage2 = zeros(size(Image,1),size(Image,2));
kernelimage2(1:length(atrouskernel2),1:length(atrouskernel2)) = kernel2;
fftkernel2 = fft2(kernelimage2);

kernel3=atrouskernel3'*atrouskernel3;
kernelimage3 = zeros(size(Image,1),size(Image,2));
kernelimage3(1:length(atrouskernel3),1:length(atrouskernel3)) = kernel3;
fftkernel3 = fft2(kernelimage3);

[P2] = atrouswaveletfft_GUI(Image,fftkernel1,fftkernel2,fftkernel3);

end

