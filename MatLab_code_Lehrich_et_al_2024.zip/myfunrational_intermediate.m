function [dif]=myfunrational_intermediate(x,length,ydata)
% MYFUNRATIONAL_INTERMEDIATE input function for fit of rational function

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

F=zeros(length,1);
for i=1:length
    F(i)=((x(1)-x(2))/((1+(exp((i-x(4)).*(x(3))))).^x(5))) + x(2); %logistic function
end
dif=F-ydata;
end