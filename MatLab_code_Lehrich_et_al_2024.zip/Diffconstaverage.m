function [Diffconstavg_high,Diffconstavg_high_rsmpl3,Diffconstavg_low,Diffconstavg_low_rsmpl3,Diffconstpatchavg_high,Diffconstpatchavg_high_rsmpl3,Diffconstpatchavg_low,Diffconstpatchavg_low_rsmpl3,cuti_high,cuti_high_rsmpl3,cuti_low,cuti_low_rsmpl3,indstable_high,indstable_high_rsmpl3,indstable_low,indstable_low_rsmpl3] = Diffconstaverage(Astim,Resultsorthigh,Resultsortlow,CutIsize,framesstim,xPSF,pxsize,upsmpl)
% DIFFCONSTAVERAGE determine diffusion constants for bright or dim events.
% By summing up several events of high or low photon number, an average
% diffusion constant can be calculated. For this, a region around the
% events is being cut out and all avents of a kind are overlaid. Then a
% gaussian function is fit to the averaged events for ten frames, that is,
% 100 ms. As the gaussian function broadens over time, its std can be used
% to determine a diffusion constant.

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

Ymat=ones(CutIsize);
Xmat=ones(CutIsize);
for i=1:CutIsize
    Ymat(:,i)=i*Ymat(:,i);
    Xmat(i,:)=i*Xmat(i,:);
end
[Tsubcentr,Tsub11,Tsub55,Template]=create_Tsubs7_3(0.1,0.02,xPSF,CutIsize);
EVektor=ones(1,10);
del=[];
xstart=[ceil(CutIsize/2),ceil(CutIsize/2)];
threshtemplate=10000;

cuti_high=zeros(CutIsize,CutIsize,framesstim,size(Resultsorthigh,2));
inti_high=zeros(framesstim,size(Resultsorthigh,2));
for i=1:size(Resultsorthigh,2)
    if Resultsorthigh(3,i)>=(floor(CutIsize/2)+1) && Resultsorthigh(3,i)<=(size(Astim,1)-(floor(CutIsize/2)+1)) && Resultsorthigh(2,i)>=(floor(CutIsize/2)+1) && Resultsorthigh(2,i)<=(size(Astim,2)-(floor(CutIsize/2)+1))
        cuti_high(:,:,:,i)=Astim(round(Resultsorthigh(3,i))-(floor(CutIsize/2)):round(Resultsorthigh(3,i))+(floor(CutIsize/2)),round(Resultsorthigh(2,i))-(floor(CutIsize/2)):round(Resultsorthigh(2,i))+(floor(CutIsize/2)),:,Resultsorthigh(4,i));
        inti_high(:,i)=sum(sum(cuti_high(:,:,:,i)));
        
        x(i)=Resultsorthigh(3,i)-round(Resultsorthigh(3,i));
        y(i)=Resultsorthigh(2,i)-round(Resultsorthigh(2,i));
        CxvalSub3(i)=round(abs((x(i)-round(x(i)))*upsmpl))*sign(x(i));
        CyvalSub3(i)=round(abs((y(i)-round(y(i)))*upsmpl))*sign(y(i));
        cuti_high_rsmpl=Astim(round(Resultsorthigh(3,i))-(floor(CutIsize/2)+1):round(Resultsorthigh(3,i))+(floor(CutIsize/2)+1),round(Resultsorthigh(2,i))-(floor(CutIsize/2)+1):round(Resultsorthigh(2,i))+(floor(CutIsize/2)+1),:,Resultsorthigh(4,i)); %relocate according to position (Cxval/Cyval), but make cutout larger (need space to relocate after resampling)
        cuti_high_rsmpl_rsz=imresize(cuti_high_rsmpl,upsmpl,'nearest'); % scale image up, 'nearest' creates copies of pixels instead of interpolating
        cuti_high_rsmpl3(:,:,:,i)=cuti_high_rsmpl_rsz((upsmpl+1+CxvalSub3(i)):(size(cuti_high,2)*upsmpl)+(upsmpl+CxvalSub3(i)),(upsmpl+1+CyvalSub3(i)):(size(cuti_high,2)*upsmpl)+(upsmpl+CyvalSub3(i)),:);
    end
end

%% stability test
lowbo=0;
hibo=1.1;
cuti_Int_high=squeeze(sum(sum(cuti_high)));
for i=1:size(cuti_Int_high,2)
    minval=min(cuti_Int_high(:,i));
    cuti_Int_high(:,i)=cuti_Int_high(:,i)-minval;
end
Intini_high=mean(cuti_Int_high(6:8,:));
cuti_Int_high_stable=cuti_Int_high;
k=1;
l=1;
indnonstable_high=[];
indstable_high=[];
for i=1:size(cuti_Int_high,2)
    for j=1:10
        if cuti_Int_high(5+j,i)<Intini_high(i).*lowbo && cuti_Int_high(5+j,i)>Intini_high(i).*hibo
            indnonstable_high(k)=i; %remember event number to be discarded
            k=k+1;
        break
        elseif cuti_Int_high(5+j,i)>Intini_high(i).*lowbo && cuti_Int_high(5+j,i)<Intini_high(i).*hibo && j==10
        indstable_high(l)=i;
        l=l+1;
        end
    end
end

% do the same thing for the resampled image
cuti_Int_high=squeeze(sum(sum(cuti_high_rsmpl3)));
for i=1:size(cuti_Int_high,2)
    minval=min(cuti_Int_high(:,i));
    cuti_Int_high(:,i)=cuti_Int_high(:,i)-minval;
end
Intini_high=mean(cuti_Int_high(6:8,:));
cuti_Int_high_stable=cuti_Int_high;
k=1;
l=1;
indnonstable_high_rsmpl3=[];
indstable_high_rsmpl3=[];
for i=1:size(cuti_Int_high,2)
    for j=1:10
        if cuti_Int_high(5+j,i)<Intini_high(i).*lowbo && cuti_Int_high(5+j,i)>Intini_high(i).*hibo
            indnonstable_high_rsmpl3(k)=i; %remember event number to be discarded
            k=k+1;
        break
        elseif cuti_Int_high(5+j,i)>Intini_high(i).*lowbo && cuti_Int_high(5+j,i)<Intini_high(i).*hibo && j==10
        indstable_high_rsmpl3(l)=i;
        l=l+1;
        end
    end
end

%% average high events and determine diffusion constant
cutistable_high=mat2gray(sum(cuti_high(:,:,1:26,indstable_high),4));
 
oldopts=optimset('lsqcurvefit');
options=optimset(oldopts,'display','off','MaxIter',10000,'MaxFunEvals',10000,'algorithm','levenberg-marquardt');
x0start=xPSF;
x0start(2)=ceil(CutIsize/2);
x0start(3)=ceil(CutIsize/2);
X_high=zeros(size(cutistable_high,3),length(x0start));
for i=1:size(cutistable_high,3)
	[x_high]=lsqnonlin(@myfun,x0start,[],[],options,CutIsize,cutistable_high(:,:,i));
	X_high(i,:)=x_high;
end
cutall_pos_high(1,:)=X_high(:,2);
cutall_pos_high(2,:)=X_high(:,3);
track1_high(1,:)=cutall_pos_high(1,6:end)*(pxsize./1000);
track1_high(2,:)=-repmat(track1_high(1,1),1,size(track1_high,2));
track1_high=sum(track1_high,1).^2;
track2_high(1,:)=cutall_pos_high(2,6:end)*(pxsize./1000);
track2_high(2,:)=-repmat(track2_high(1,1),1,size(track2_high,2));
track2_high=sum(track2_high,1).^2;
track_high=track1_high+track2_high;
atrack=polyfit(10:10:100,((track_high(1:10))),1); 
Diffconstpatchavg_high=(1000.*atrack(1))/4;

stdsnm_high=X_high(:,1)*pxsize;
stdsnm_high2=stdsnm_high(6:end);
stdsnm_high2=cat(1,xPSF(1).*pxsize,stdsnm_high2);
ahigh=polyfit(0:10:100,(2.*(((stdsnm_high2(1:11))./1000).^2))',1); 
Diffconstavg_high=(1000.*ahigh(1))/4;

% same thing for resampled ROIs:
cutistable_high_rsmpl3=mat2gray(sum(cuti_high_rsmpl3(:,:,1:26,indstable_high_rsmpl3),4));
cutistable_high_rsmpl3=imresize(cutistable_high_rsmpl3,(1/upsmpl));
oldopts=optimset('lsqcurvefit');
options=optimset(oldopts,'display','off','MaxIter',10000,'MaxFunEvals',10000,'algorithm','levenberg-marquardt');
x0start=xPSF;
x0start(2)=ceil(CutIsize/2);
x0start(3)=ceil(CutIsize/2);
X_high=zeros(size(cutistable_high_rsmpl3,3),length(x0start));
for i=1:size(cutistable_high_rsmpl3,3)
	[x_high]=lsqnonlin(@myfun,x0start,[],[],options,CutIsize,cutistable_high_rsmpl3(:,:,i));
	X_high(i,:)=x_high;
end

cutall_pos_high(1,:)=X_high(:,2);
cutall_pos_high(2,:)=X_high(:,3);
track1_high(1,:)=cutall_pos_high(1,6:end)*(pxsize./1000);
track1_high(2,:)=-repmat(track1_high(1,1),1,size(track1_high,2));
track1_high=sum(track1_high,1).^2;
track2_high(1,:)=cutall_pos_high(2,6:end)*(pxsize./1000);
track2_high(2,:)=-repmat(track2_high(1,1),1,size(track2_high,2));
track2_high=sum(track2_high,1).^2;
track_high=track1_high+track2_high;
atrack=polyfit(10:10:100,((track_high(1:10))),1); 
Diffconstpatchavg_high_rsmpl3=(1000.*atrack(1))/4;

stdsnm_high=X_high(:,1)*pxsize;
stdsnm_high2=stdsnm_high(6:end);
stdsnm_high2=cat(1,xPSF(1).*pxsize,stdsnm_high2); 
ahigh=polyfit(0:10:100,(2.*(((stdsnm_high2(1:11))./1000).^2))',1); 
Diffconstavg_high_rsmpl3=(1000.*ahigh(1))/4;

%% average low events and determine diffusion constant
cuti_low=zeros(CutIsize,CutIsize,framesstim,size(Resultsortlow,2));
inti_low=zeros(framesstim,size(Resultsortlow,2));
for i=1:size(Resultsortlow,2)
    if round(Resultsortlow(3,i))>(floor(CutIsize/2)+1) && round(Resultsortlow(3,i))<(size(Astim,1)-(floor(CutIsize/2)+1)) && round(Resultsortlow(2,i))>(floor(CutIsize/2)+1) && round(Resultsortlow(2,i))<(size(Astim,2)-(floor(CutIsize/2)+1))
        cuti_low(:,:,:,i)=Astim(round(Resultsortlow(3,i))-(floor(CutIsize/2)):round(Resultsortlow(3,i))+(floor(CutIsize/2)),round(Resultsortlow(2,i))-(floor(CutIsize/2)):round(Resultsortlow(2,i))+(floor(CutIsize/2)),:,Resultsortlow(4,i));
        inti_low(:,i)=sum(sum(cuti_low(:,:,:,i)));
        x(i)=Resultsortlow(3,i)-round(Resultsortlow(3,i));%+ceil(CutIsize/2);
        y(i)=Resultsortlow(2,i)-round(Resultsortlow(2,i));%+ceil(CutIsize/2);
        CxvalSub3(i)=round(abs((x(i)-ceil(x(i)))*upsmpl))*sign(x(i));
        CyvalSub3(i)=round(abs((y(i)-ceil(y(i)))*upsmpl))*sign(y(i));
        cuti_low_rsmpl=Astim(round(Resultsortlow(3,i))-(floor(CutIsize/2)+1):round(Resultsortlow(3,i))+(floor(CutIsize/2)+1),round(Resultsortlow(2,i))-(floor(CutIsize/2)+1):round(Resultsortlow(2,i))+(floor(CutIsize/2)+1),:,Resultsortlow(4,i)); %relocate according to position (Cxval/Cyval), but make cutout larger (need space to relocate after resampling)
        cuti_low_rsmpl_rsz=imresize(cuti_low_rsmpl,upsmpl,'nearest'); % scale image up, 'nearest' creates copies of pixels instead of interpolating
        cuti_low_rsmpl3(:,:,:,i)=cuti_low_rsmpl_rsz((upsmpl+1+CxvalSub3(i)):(size(cuti_low,2)*upsmpl)+(upsmpl+CxvalSub3(i)),(upsmpl+1+CyvalSub3(i)):(size(cuti_low,2)*upsmpl)+(upsmpl+CyvalSub3(i)),:);
        end
end

%% stability test
lowbo=0.7;
hibo=1.1;
cuti_Int_low=squeeze(sum(sum(cuti_low)));
for i=1:size(cuti_Int_low,2)
    minval=min(cuti_Int_low(:,i));
    cuti_Int_low(:,i)=cuti_Int_low(:,i)-minval;
end
Intini_low=mean(cuti_Int_low(6:8,:));
cuti_Int_low_stable=cuti_Int_low;
k=1;
l=1;
indnonstable_low=[];
indstable_low=[];
for i=1:size(cuti_Int_low,2)
    for j=1:10
        if cuti_Int_low(5+j,i)<Intini_low(i).*lowbo && cuti_Int_low(5+j,i)>Intini_low(i).*hibo
            indnonstable_low(k)=i; %remember event number to be discarded
            k=k+1;
        break
        elseif cuti_Int_low(5+j,i)>Intini_low(i).*lowbo && cuti_Int_low(5+j,i)<Intini_low(i).*hibo && j==10
        indstable_low(l)=i;
        l=l+1;
        end
    end
end

% redo for resampled ROIs:
lowbo=0.7;
hibo=1.1;
cuti_Int_low=squeeze(sum(sum(cuti_low_rsmpl3)));
for i=1:size(cuti_Int_low,2)
    minval=min(cuti_Int_low(:,i));
    cuti_Int_low(:,i)=cuti_Int_low(:,i)-minval;
end
Intini_low=mean(cuti_Int_low(6:8,:));
cuti_Int_low_stable=cuti_Int_low;
k=1;
l=1;
indnonstable_low_rsmpl3=[];
indstable_low_rsmpl3=[];
for i=1:size(cuti_Int_low,2)
    for j=1:10
        if cuti_Int_low(5+j,i)<Intini_low(i).*lowbo && cuti_Int_low(5+j,i)>Intini_low(i).*hibo
            indnonstable_low_rsmpl3(k)=i; %remember event number to be discarded
            k=k+1;
        break
        elseif cuti_Int_low(5+j,i)>Intini_low(i).*lowbo && cuti_Int_low(5+j,i)<Intini_low(i).*hibo && j==10
        indstable_low_rsmpl3(l)=i;
        l=l+1;
        end
    end
end

cutistable_low=mat2gray(sum(cuti_low(:,:,1:26,indstable_low),4));
X_low=zeros(size(cutistable_low,3),length(x0start));

oldopts=optimset('lsqcurvefit');
options=optimset(oldopts,'display','off','MaxIter',10000,'MaxFunEvals',10000,'algorithm','levenberg-marquardt');%'LevenbergMarquardt','on','LargeScale','on',);
x0start=xPSF;
x0start(2)=ceil(CutIsize/2);
x0start(3)=ceil(CutIsize/2);
for i=1:size(cutistable_low,3)
	[x_low]=lsqnonlin(@myfun,x0start,[],[],options,CutIsize,cutistable_low(:,:,i));
	X_low(i,:)=x_low;
end

cutall_pos_low(1,:)=X_low(:,2);
cutall_pos_low(2,:)=X_low(:,3);
track1_low(1,:)=cutall_pos_low(1,6:end)*(pxsize./1000);
track1_low(2,:)=-repmat(track1_low(1,1),1,size(track1_low,2));
track1_low=sum(track1_low,1).^2;
track2_low(1,:)=cutall_pos_low(2,6:end)*(pxsize./1000);
track2_low(2,:)=-repmat(track2_low(1,1),1,size(track2_low,2));
track2_low=sum(track2_low,1).^2;
track_low=track1_low+track2_low;
atrack=polyfit(10:10:100,((track_low(1:10))),1); 
Diffconstpatchavg_low=(1000.*atrack(1))/4;

stdsnm_low=X_low(:,1)*pxsize;
stdsnm_low2=stdsnm_low(6:end);
stdsnm_low2=cat(1,xPSF(1).*pxsize,stdsnm_low2); 
alow=polyfit(0:10:100,(2.*(((stdsnm_low2(1:11))./1000).^2))',1);
Diffconstavg_low=(1000.*alow(1))/4;

% same thing for resampled ROIs:
cutistable_low_rsmpl3=mat2gray(sum(cuti_low_rsmpl3(:,:,1:26,indstable_low_rsmpl3),4));
cutistable_low_rsmpl3=imresize(cutistable_low_rsmpl3,(1/upsmpl));
oldopts=optimset('lsqcurvefit');
options=optimset(oldopts,'display','off','MaxIter',10000,'MaxFunEvals',10000,'algorithm','levenberg-marquardt');
x0start=xPSF;
x0start(2)=ceil(CutIsize/2);
x0start(3)=ceil(CutIsize/2);
X_low=zeros(size(cutistable_low_rsmpl3,3),length(x0start));
for i=1:size(cutistable_low_rsmpl3,3)
	[x_low]=lsqnonlin(@myfun,x0start,[],[],options,CutIsize,cutistable_low_rsmpl3(:,:,i));
	X_low(i,:)=x_low;
end

cutall_pos_low(1,:)=X_low(:,2);
cutall_pos_low(2,:)=X_low(:,3);
track1_low(1,:)=cutall_pos_low(1,6:end)*(pxsize./1000);
track1_low(2,:)=-repmat(track1_low(1,1),1,size(track1_low,2));
track1_low=sum(track1_low,1).^2;
track2_low(1,:)=cutall_pos_low(2,6:end)*(pxsize./1000);
track2_low(2,:)=-repmat(track2_low(1,1),1,size(track2_low,2));
track2_low=sum(track2_low,1).^2;
track_low=track1_low+track2_low;
atrack=polyfit(10:10:100,((track_low(1:10))),1); 
Diffconstpatchavg_low_rsmpl3=(1000.*atrack(1))/4;

stdsnm_low=X_low(:,1)*pxsize;
stdsnm_low2=stdsnm_low(6:end);
stdsnm_low2=cat(1,xPSF(1).*pxsize,stdsnm_low2); 
alow=polyfit(0:10:100,(2.*(((stdsnm_low2(1:11))./1000).^2))',1); 
Diffconstavg_low_rsmpl3=(1000.*alow(1))/4;
end

