function [Image,Positionx,Positiony,Direction] = diffusion2d(xPSF,numparticles,numsteps,time,D,pxsize)
%DIFFUSION2D 2d random walk monte carlo simulation of n particles 

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

Imsize=41;
munoise = 4.4505E-04;
% multiply with sqrt(10) to account for real noise even though images are
% binned later (10x binning)
sigmanoise = sqrt(10).*8.6625; 
Intensity = 19.4325; %one pHluorin
% generate background; normally distributed noise with mu and sigma defined:
for g=1:5
bgbl(:,:,g) = mean(munoise + sigmanoise.*randn(Imsize,Imsize,10),3);
end
bgevent = munoise + sigmanoise.*randn(Imsize,Imsize,numsteps);
bg = cat(3,bgbl,bgevent);

% initialise the particles (random starting points and impulses)
positionx=zeros(1,numparticles);
positiony=zeros(1,numparticles);
direction=zeros(1,numparticles);
Positionx=[];
Positiony=[];
Direction=[];
for i=1:numparticles
positionx(1, i) = ceil(Imsize./2);
positiony(1, i) = ceil(Imsize./2);
end 
Positionx=cat(1,Positionx,positionx);
Positiony=cat(1,Positiony,positiony);
Direction=cat(1,Direction,direction);
% s is the stepwidth: (s^2 = 4Dt)
% D is the diffusion constant, t the time per step
s=sqrt(4*D*time)*(1/pxsize); %in pixel

% generate signal on top:
Image=zeros(Imsize,Imsize,numsteps);
diffusionIm=zeros(Imsize,Imsize);
Imagebl(:,:,1:5)=bg(:,:,1:5);
for l=1:numsteps
diffusionim=zeros(Imsize,Imsize);
for k=1:numparticles
    for i=1:Imsize
        for j=1:Imsize
            diffusionIm(i,j)=(Intensity*exp(-((((i-positionx(k)).^2)+(j-positiony(k)).^2))/(2*xPSF(1).^2))); %%%%%%%%%% Intensity decreased to 1/10, see function20160104diary.m
        end
    end
    diffusionim = diffusionIm + diffusionim;
end
Fpoiss=poissrnd(diffusionim); %add poisson-distributed noise from the signal
Image(:,:,l)=bg(:,:,l+5)+Fpoiss;
    for i = 1:numparticles
        direction(1, i) = rand(1)*2*pi;
        while direction(1, i)==0
            direction(1, i) = rand(1)*2*pi;
        end
        positionx(1, i) = positionx(1, i) + s*cos(direction(1, i));
        positiony(1, i) = positiony(1, i) + s*sin(direction(1, i));
    end
    Positionx=cat(1,Positionx,positionx);
    Positiony=cat(1,Positiony,positiony);
    Direction=cat(1,Direction,direction);
end
Image=cat(3,Imagebl,Image);
end

