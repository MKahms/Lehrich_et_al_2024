function [dif]=myfunrationalsim(x,length,ydata)
% MYFUNRATIONALSIM input function for fit of rational function

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

F=zeros(length,1);
for i=1:length
    F(i)=((1-x(1))/((1+(x(4).*exp((i-x(3)).*(x(2))))).^x(5))) + x(1);
end
dif=F-ydata;
end