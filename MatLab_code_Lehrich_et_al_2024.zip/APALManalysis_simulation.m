function [varargout]=APALManalysis_simulation(xPSF,Diffconst,pxsize)
% APALMANALYSIS_SIMULATION analysis of particles generated via 2d random
% walk monte carlo simulation

% xPSF              vector containing fitting parameter for the PSF of the
%                   imaging system (see function myfun.m)
% Diffconst         Diffusion coefficient used as input for simulation
% pxsize            pixel size of the camera, pxsize = 65nm for the
%                   Hamamatsu Orca Flash4 V2 and an 100x objective.

%                   Code written by Julia Lehrich,
%                   Matlab version R2019b, September 2024

[sim_Image,sim_cuti_high,sim_wavelet,sim_waveletfilt,sim_Diffconstwavelet,sim_Cxval,sim_Cyval,sim_Int7,sim_Int13_7ring,sim_kymograph,sim_kymographdIdr,sim_radiusFWHM,sim_Diffconst,sim_Diffconstpatch,sim_Result,sim_Positionx,sim_Positiony,sim_Direction] = diffusion2dSimulation(xPSF,Diffconst,pxsize);
% apply analysisGUI_sim:

assignin('base','sim_cuti_high',sim_cuti_high);
assignin('base','sim_wavelet',sim_wavelet);
assignin('base','sim_waveletfilt',sim_waveletfilt);
assignin('base','sim_Diffconstwavelet',sim_Diffconstwavelet);
assignin('base','sim_Cxval',sim_Cxval);
assignin('base','sim_Cyval',sim_Cyval);
assignin('base','sim_Int7',sim_Int7);
assignin('base','sim_Int13_7ring',sim_Int13_7ring);
assignin('base','sim_kymograph',sim_kymograph);
assignin('base','sim_radiusFWHM',sim_radiusFWHM);
assignin('base','sim_Diffconst',sim_Diffconst);
assignin('base','sim_Diffconstpatch',sim_Diffconstpatch);
assignin('base','sim_Result',sim_Result);
assignin('base','sim_Diffconstwavelet',sim_Diffconstwavelet);

guide;

sim_GUIanalyseevents=evalin('base','sim_GUIanalyseevents',sim_GUIanalyseevents);
sim_GUIdiscardevents=evalin('base','sim_GUIdiscardevents',sim_GUIdiscardevents);

for i=1:size(sim_GUIanalyseevents,1)
sim_GUIanalyseeventsmat(i,1)=str2double(sim_GUIanalyseevents(i));
end
for i=1:size(sim_GUIdiscardevents,1)
sim_GUIdiscardeventsmat(i,1)=str2double(sim_GUIdiscardevents(i));
end
sim_Diffconst_analyse=sim_Diffconst(sim_GUIanalyseeventsmat);
%% plot histogram

sim_Diffconst_avg=median(sim_Diffconst_analyse);
sim_Diffconstpatch_avg=median(sim_Diffconstpatch(sim_GUIanalyseeventsmat));

sim_Diffconst_analyse_sort=sort(sim_Diffconst_analyse);
a=0.02;
b=0.04;
minbo_sim=a.*(floor((min(sim_Diffconst_analyse_sort)./a)));
maxbo_sim=b.*(ceil((max(sim_Diffconst_analyse)./b)));
[counts_sim,bins_sim]=hist(sim_Diffconst_analyse,minbo_sim:a:maxbo_sim);

cmap=colormap(jet(22));
figure, stairs(bins_sim,counts_sim,'LineWidth',2,'Color',cmap(3,:));

%% For the averaging analysis, only take those events which also were analysed with the GUI:
CutIsize=9;
cutiavg=mat2gray(sum(sim_cuti_high(3:11,3:11,1:26,ind_stable),4));
oldopts=optimset('lsqcurvefit');
options=optimset(oldopts,'display','off','MaxIter',10000,'MaxFunEvals',10000,'algorithm','levenberg-marquardt');
x0start=xPSF;
X_avg=zeros(size(cutiavg,3),length(x0start));
for i=1:size(cutiavg,3)
[x_avg]=lsqnonlin(@myfun,x0start,[],[],options,CutIsize,cutiavg(:,:,i));
X_avg(i,:)=x_avg;
end
stdsnm_avg=X_avg(:,1)*65;
stdsnm_avg2=stdsnm_avg(6:end);
aavg=polyfit(10:10:100,(2.*(((stdsnm_avg2(1:10))./1000).^2))',1);
Diffconstavg=(1000.*aavg(1))/4;
end