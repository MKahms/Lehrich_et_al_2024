function [W2] = atrouswaveletfft_GUI(Image,fftkernel1,fftkernel2,fftkernel3)
% ATROUSWAVELETFFT_GUI multiplication of � trous kernel and image in 
% fourier space, making use of the fast fourier transformation

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

fftimage = fft2(Image); fftblurimage1 = fftimage.*fftkernel1; A1 = circshift(ifft2(fftblurimage1),[-2 -2]); 
fftblurimage2 = fftblurimage1.*fftkernel2; A2 = circshift(ifft2(fftblurimage2),[-6 -6]); 
W2=A1-A2;
end

