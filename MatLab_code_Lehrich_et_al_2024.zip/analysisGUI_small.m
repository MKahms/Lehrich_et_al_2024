function varargout = analysisGUI_small(varargin)
% ANALYSISGUI_SMALL M-file for analysisGUI_small.fig
% ANALYSISGUI M-file for analysisGUI.fig
%               ANALYSISGUI, by itself, creates a new ANALYSISGUI or raises 
%               the existing singleton*.
%
%               H = ANALYSISGUI returns the handle to a new ANALYSISGUI or 
%               the handle tothe existing singleton*.
%
%               ANALYSISGUI('CALLBACK',hObject,eventData,handles,...) calls 
%               the local function named CALLBACK in ANALYSISGUI.M with the 
%               given input arguments.
%
%               ANALYSISGUI('Property','Value',...) creates a new 
%               ANALYSISGUI or raises the existing singleton*.  Starting 
%               from the left, property value pairs areapplied to the GUI 
%               before analysisGUI_OpeningFcn gets called.  Anunrecognized 
%               property name or invalid value makes property application 
%               stop.  All inputs are passed to analysisGUI_OpeningFcn via
%               varargin.
%
%               *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows 
%               only one instance to run (singleton)".
%
%               See also: GUIDE, GUIDATA, GUIHANDLES

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

% Last Modified by GUIDE v2.5 23-Feb-2016 08:23:41

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @analysisGUI_small_OpeningFcn, ...
                   'gui_OutputFcn',  @analysisGUI_small_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before analysisGUI_small is made visible.
function analysisGUI_small_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to analysisGUI_small (see VARARGIN)

% Choose default command line output for analysisGUI_small
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes analysisGUI_small wait for user response (see UIRESUME)
% uiwait(handles.figure1);

pxsize=evalin('base','pxsize');
cuti_high=evalin('base','small_cuti_high');
setappdata(handles.slider1,'cuti_high',cuti_high);
imagesc(cuti_high(:,:,7,1), 'Parent', handles.axes1);
axes(handles.axes1);
hold off
xlabel('length in pixel');
ylabel('length in pixel');
title('stimulation frame');

wavelet=evalin('base','small_wavelet');
setappdata(handles.slider1,'wavelet',wavelet);
imagesc(wavelet(:,:,7,1), 'Parent', handles.axes9);
axes(handles.axes9);
hold off
xlabel('length in pixel');
ylabel('length in pixel');
title('a trous wavelet');
waveletfilt=evalin('base','small_waveletfilt');
setappdata(handles.slider1,'waveletfilt',waveletfilt);
imagesc(waveletfilt(:,:,7,1), 'Parent', handles.axes7);
axes(handles.axes7);
hold off
xlabel('length in pixel');
ylabel('length in pixel');
title('a trous wavelet');
area=sum(sum(waveletfilt(:,:,7,1)));
set(handles.edit8,'String',num2str(area));
plot(10:10:100,((((pxsize./1000).^2).*(squeeze(sum(sum(waveletfilt(:,:,6:15,1),1),2))))./pi),'c','Parent', handles.axes8);
axes(handles.axes8);
hold off
xlabel('time in ms');
ylabel('radius of fit in �m�');
title('wavelet filter: diffusion');
Diffconstwavelet=evalin('base','small_Diffconstwavelet');
set(handles.edit9,'String',num2str(Diffconstwavelet(1)));

Cxval=evalin('base','small_Cxval');
Cyval=evalin('base','small_Cyval');
plot(60:10:150,(Cxval(6:15,1)).^2 + (Cyval(6:15,1)).^2, 'Parent', handles.axes2)
axes(handles.axes2);
hold off
xlabel('time in ms');
ylabel('delta r� from origin in pixel');
title('centroid tracking; patch diffusion');

Int5=evalin('base','small_Int5');
Int9_5ring=evalin('base','small_Int9_5ring');
plot(60:10:200,(Int5(6:20,1)./(Int5(6:20,1)+Int9_5ring(6:20,1))),'Parent',handles.axes3)
axes(handles.axes3);
hold off
xlabel('time in ms');
ylabel('ratio circle 5 / sum circle 5 ring 9');
title('annular intensity ratio');

plot(60:10:200,(Int5(6:20,1)),'Parent', handles.axes4)
hold(handles.axes4,'on');
plot(60:10:200,(Int9_5ring(6:20,1)),'r','Parent', handles.axes4) 
axes(handles.axes4);
hold(handles.axes4,'off');
xlabel('time in ms');
ylabel('intensities circle 5 (blue) and ring 9 (red)');
title('annular intensity');

kymograph=evalin('base','small_kymograph');
imagesc(kymograph(:,5:15,1), 'Parent', handles.axes5);
axes(handles.axes5);
hold off
xlabel('time in ms');
ylabel('distance in pixel');
title('radial kymograph');

radiusFWHM=evalin('base','small_radiusFWHM');
plot(10:10:100,((pxsize./1000).*radiusFWHM(2,6:15,1)).^2,'g','Parent', handles.axes6);
axes(handles.axes6);
hold off
xlabel('time in ms');
ylabel('radius of fit in �m�');
title('half-maximum radius in kymograph');

Diffconst=evalin('base','small_Diffconst');
set(handles.edit5,'String',num2str(Diffconst(1)));

Diffconstpatch=evalin('base','small_Diffconstpatch');
set(handles.edit10,'String',num2str(Diffconstpatch(1)));

Intensity=evalin('base','Resultsorthigh');
set(handles.edit6,'String',num2str(Intensity(1,1)));
IntsinglepHluorin=303.1; %photons; Intensity also in photons
IntensitypHluorinequivalent=Intensity(1,:)./IntsinglepHluorin;
set(handles.edit7,'String',num2str(IntensitypHluorinequivalent(1)));

 % set the slider range and step size
 numSteps = size(cuti_high,4);
 set(handles.slider1, 'Min', 1);
 set(handles.slider1, 'Max', numSteps);
 set(handles.slider1, 'Value', 1);
 set(handles.slider1, 'SliderStep', [1/(numSteps-1) , 1/(numSteps-1) ]);
 
 % set the slider range and step size
 numSteps2 = size(cuti_high,3);
 set(handles.slider2, 'Min', 1);
 set(handles.slider2, 'Max', numSteps2);
 set(handles.slider2, 'Value', 7);
 set(handles.slider2, 'SliderStep', [1/(numSteps2-1) , 1/(numSteps2-1) ]);



% --- Outputs from this function are returned to the command line.
function varargout = analysisGUI_small_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%set(handles.listbox1,'String',num2str(get(handles.slider1,'Value')))

set(handles.listbox1,'String',[get(handles.listbox1,'String'); {num2str(get(handles.slider1,'Value'))}])

%oldstr = {num2str(get(handles.listbox1,'Value'))}; % The string as it is now.
%addstr = {num2str(get(handles.slider1,'Value'))}; % The string to add to the stack.
% set(S.ls,'str',{addstr{:},oldstr{:}});  % Put the new string on top -OR-
%set(handles.listbox1,'String',{oldstr{:},addstr{:}});  % Put the new string on bottom.

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.listbox2,'String',[get(handles.listbox2,'String'); {num2str(get(handles.slider1,'Value'))}])

% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1

% --- Executes on mouse press over axes background.
function axes1_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
%set(handles.edit1,'String',num2str(slice))

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

slice = round(get(handles.slider1,'Value')); % returns position of slider
set(handles.edit1,'String',num2str(slice));

set(handles.slider2,'Value',7); % returns position of slider
set(handles.edit2,'String',num2str(7));

Diffconst=evalin('base','small_Diffconst');
set(handles.edit5,'String',num2str(Diffconst(slice)));

Diffconstpatch=evalin('base','small_Diffconstpatch');
set(handles.edit10,'String',num2str(Diffconstpatch(slice)));

I = getappdata(handles.slider1,'cuti_high');
cla(handles.axes1) %clear handles from previous image
imagesc(I(:,:,7,slice), 'Parent', handles.axes1);
axes(handles.axes1);
hold off
xlabel('length in pixel');
ylabel('length in pixel');
title('stimulation frame');

H = getappdata(handles.slider1,'wavelet');
cla(handles.axes9)
imagesc(H(:,:,7,slice), 'Parent', handles.axes9);
axes(handles.axes9);
hold off
xlabel('length in pixel');
ylabel('length in pixel');
title('a trous wavelet');
K = getappdata(handles.slider1,'waveletfilt');
cla(handles.axes7) %clear handles from previous image
imagesc(K(:,:,7,slice), 'Parent', handles.axes7);
axes(handles.axes7);
hold off
xlabel('length in pixel');
ylabel('length in pixel');
title('a trous wavelet');
area=sum(sum(K(:,:,7,slice)));
set(handles.edit8,'String',num2str(area));
plot(10:10:100,((((pxsize./1000).^2).*(squeeze(sum(sum(K(:,:,6:15,slice),1),2))))./pi),'c','Parent', handles.axes8);
axes(handles.axes8);
hold off
xlabel('time in ms');
ylabel('radius of fit in �m�');
title('wavelet filter: diffusion');
Diffconstwavelet=evalin('base','small_Diffconstwavelet');
set(handles.edit9,'String',num2str(Diffconstwavelet(slice)));

kymograph=evalin('base','small_kymograph');
imagesc(kymograph(:,5:15,slice), 'Parent', handles.axes5);
axes(handles.axes5);
hold off
xlabel('time in ms');
ylabel('distance in pixel');
title('radial kymograph');

Cxval=evalin('base','small_Cxval');
Cyval=evalin('base','small_Cyval');
plot(60:10:150,((Cxval(6:15,slice)).^2 + (Cyval(6:15,slice)).^2), 'Parent', handles.axes2)
axes(handles.axes2);
hold off
xlabel('time in ms');
ylabel('delta r� from origin in pixel');
title('centroid tracking; patch diffusion');

Int5=evalin('base','small_Int5');
Int9_5ring=evalin('base','small_Int9_5ring');
plot(60:10:200,(Int5(6:20,slice)./(Int5(6:20,slice)+Int9_5ring(6:20,slice))),'Parent',handles.axes3)
axes(handles.axes3);
hold off
xlabel('time in ms');
ylabel('ratio circle 5 / sum circle 5 ring 9');
title('annular intensity ratio');

plot(60:10:200,(Int5(6:20,slice)),'Parent', handles.axes4)
hold(handles.axes4,'on');
plot(60:10:200,(Int9_5ring(6:20,slice)),'r','Parent', handles.axes4) 
axes(handles.axes4);
hold(handles.axes4,'off');
xlabel('time in ms');
ylabel('intensities circle 5 (blue) and ring 9 (red)');
title('annular intensity');

radiusFWHM=evalin('base','small_radiusFWHM');
plot(10:10:100,((pxsize./1000).*radiusFWHM(2,6:15,slice)).^2,'g','Parent', handles.axes6);
axes(handles.axes6);
hold off
xlabel('time in ms');
ylabel('radius of fit in �m�');
title('half-maximum radius in kymograph');

Intensity=evalin('base','Resultsorthigh');
set(handles.edit6,'String',num2str(Intensity(1,slice)));
IntsinglepHluorin=303.1; %photons; Intensity also in photons
IntensitypHluorinequivalent=Intensity(1,:)./IntsinglepHluorin;
set(handles.edit7,'String',num2str(IntensitypHluorinequivalent(slice)));

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function axes3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes3


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox2.
function listbox2_Callback(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox2


% --- Executes during object creation, after setting all properties.
function listbox2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
valind1 = get(handles.listbox1,'Value');
valnames1 = get(handles.listbox1,'String');
valnames1(valind1) = [];
set(handles.listbox1,'String',valnames1,'Value',[]);

% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
valind2 = get(handles.listbox2,'Value');
valnames2 = get(handles.listbox2,'String');
valnames2(valind2) = [];
set(handles.listbox2,'String',valnames2,'Value',[]);
%'Value',[] necessary to prevent list from disappearing after removal of last element


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
slice = round(get(handles.slider1,'Value')); % returns position of slider
slice2 = round(get(handles.slider2,'Value')); %round, otherwise some frames won't be displayed properly
set(handles.edit2,'String',num2str(slice2));

%cuti_high=evalin('base','cuti_high'); %read in data for every function or
%only once and pass data between functions via setappdata and getappdata
J = getappdata(handles.slider1,'cuti_high');
cla(handles.axes1) %clear handles from previous image
imagesc(J(:,:,slice2,slice), 'Parent', handles.axes1);
axes(handles.axes1);
hold off
xlabel('length in pixel');
ylabel('length in pixel');
title('stimulation frame');

I = getappdata(handles.slider1,'wavelet');
cla(handles.axes9)
imagesc(I(:,:,slice2,slice), 'Parent', handles.axes9);
axes(handles.axes9);
hold off
xlabel('length in pixel');
ylabel('length in pixel');
title('a trous wavelet');
L = getappdata(handles.slider1,'waveletfilt');
cla(handles.axes7) %clear handles from previous image
imagesc(L(:,:,slice2,slice), 'Parent', handles.axes7);
axes(handles.axes7);
hold off
xlabel('length in pixel');
ylabel('length in pixel');
title('a trous wavelet');
area=sum(sum(L(:,:,slice2,slice)));
set(handles.edit8,'String',num2str(area));

% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
GUIanalyseevents=get(handles.listbox1,'String');
GUIdiscardevents=get(handles.listbox2,'String');
assignin('base','small_GUIanalyseevents',GUIanalyseevents)
assignin('base','small_GUIdiscardevents',GUIdiscardevents)



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
