function [P12,P23,P34,P45,P56] = atrouswavelet(Image)

%ATROUSWAVELET apply a trous wavelet filtering on single image

% Image         Image to be filtered
% P23           first wavelet plane containing fine structures (in momentum
%               space; with high frequencies in fourier space)
% P34           second wavelet plane
% P45           third wavelet plane
% P56           fourth wavelet plane containing large stuctures (in
%               momentum space; with low frequencies in fourier space

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

atrouskernel1=[1/16, 1/4, 3/8, 1/4, 1/16];
atrouskernel2=[1/16, 0, 1/4, 0, 3/8, 0, 1/4, 0, 1/16];
atrouskernel3=[1/16, 0, 0, 0, 1/4, 0, 0, 0, 3/8, 0, 0, 0, 1/4, 0, 0, 0, 1/16];
atrouskernel4=[1/16, 0, 0, 0, 0, 0, 0, 0, 1/4, 0, 0, 0, 0, 0, 0, 0, 3/8, 0, 0, 0, 0, 0, 0, 0, 1/4, 0, 0, 0, 0, 0, 0, 0, 1/16];
atrouskernel5=[1/16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1/4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3/8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1/4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1/16];
atrouskernel6=[1/16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1/4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3/8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1/4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1/16];

kernel1=atrouskernel1'*atrouskernel1;
kernelimage1 = zeros(size(Image,1),size(Image,2));
kernelimage1(1:length(atrouskernel1),1:length(atrouskernel1)) = kernel1;
fftkernel1 = fft2(kernelimage1);

kernel2=atrouskernel2'*atrouskernel2;
kernelimage2 = zeros(size(Image,1),size(Image,2));
kernelimage2(1:length(atrouskernel2),1:length(atrouskernel2)) = kernel2;
fftkernel2 = fft2(kernelimage2);

kernel3=atrouskernel3'*atrouskernel3;
kernelimage3 = zeros(size(Image,1),size(Image,2));
kernelimage3(1:length(atrouskernel3),1:length(atrouskernel3)) = kernel3;
fftkernel3 = fft2(kernelimage3);

kernel4=atrouskernel4'*atrouskernel4;
kernelimage4 = zeros(size(Image,1),size(Image,2));
kernelimage4(1:length(atrouskernel4),1:length(atrouskernel4)) = kernel4;
fftkernel4 = fft2(kernelimage4);

kernel5=atrouskernel5'*atrouskernel5;
kernelimage5 = zeros(size(Image,1),size(Image,2));
kernelimage5(1:length(atrouskernel5),1:length(atrouskernel5)) = kernel5;
fftkernel5 = fft2(kernelimage5);

kernel6=atrouskernel6'*atrouskernel6;
kernelimage6 = zeros(size(Image,1),size(Image,2));
kernelimage6(1:length(atrouskernel6),1:length(atrouskernel6)) = kernel6;
fftkernel6 = fft2(kernelimage6);

%}
P12=zeros(size(Image,1),size(Image,2),size(Image,3));
P23=zeros(size(Image,1),size(Image,2),size(Image,3));
P34=zeros(size(Image,1),size(Image,2),size(Image,3));
P45=zeros(size(Image,1),size(Image,2),size(Image,3));
P56=zeros(size(Image,1),size(Image,2),size(Image,3));

h = waitbar(0,'Computing wavelet filter...');
for i=1:size(Image,3)
    waitbar(i / size(Image,3))
    [P12(:,:,i),P23(:,:,i),P34(:,:,i),P45(:,:,i),P56(:,:,i)] = atrouswaveletfft(Image(:,:,i),fftkernel1,fftkernel2,fftkernel3,fftkernel4,fftkernel5,fftkernel6);
end
close(h)

end

