function [DiffIm,avgbefore,framesafter] = diffusionanalysisreadin(stimvec,avgbefore,framesafter,stimframedel,stimframeshift,dirname,fname,calcdirname)                                                                                                             
% COUNTHISTREADIN reads in data for further processing in function
% counthist

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

[A]=imreadtiff2(dirname,fname,calcdirname);
A=single(A);

if stimframedel==1      %stimulation frame is not taken into account
    stimframe=stimvec+1+stimframeshift; %with the rolling shutter of the
                        %Orca camera, the stimulation trigger number n
                        %occurs in frame n+1
    stimframebefore=stimframe-avgbefore; %first frame for averaging,
                        %according to the number of frames to be averaged
                        %prestim (avgbefore) 
    %stimframeafter=stimframe+framesafter; %last frame for analysis, according
                        %to the number of frames to be averaged poststim
                        %(framesafter)
                        
    Abefore=zeros(size(A,1),size(A,2),framesafter,numel(stimframe),'single');
    Aafter=zeros(size(A,1),size(A,2),framesafter,numel(stimframe),'single');
    for i=1:numel(stimframe)
        Abefore(:,:,:,i)=repmat((sum(A(:,:,stimframebefore(i):stimframe(i)-1),3)/avgbefore),[1 1 framesafter 1]);
        Aafter(:,:,:,i)=A(:,:,stimframebefore(i):stimframebefore(i)+framesafter-1);
        %average frames after stimulation (including stimulation frame)
    end
end
if stimframedel==0      %stimulation frame is taken into account
    stimframe=stimvec+1+stimframeshift;
    stimframebefore=stimframe-avgbefore; 
    %stimframeafter=stimframe+framesafter;
    
    Abefore=zeros(size(A,1),size(A,2),framesafter,numel(stimframe),'single');
    Aafter=zeros(size(A,1),size(A,2),framesafter,numel(stimframe),'single');
    for i=1:numel(stimframe)
        Abefore(:,:,:,i)=repmat((sum(A(:,:,stimframebefore(i):stimframe(i)-1),3)/avgbefore),[1 1 framesafter 1]);
        Aafter(:,:,:,i)=A(:,:,stimframebefore(i):stimframebefore(i)+framesafter-1);
        %average frames after stimulation (including stimulation frame)
    end
end  
clear A stimvec stimframe stimframebefore stimframeafter
DiffIm=Aafter-Abefore; %difference image

assignin('base','stimframedel',stimframedel);
assignin('base','stimframeshift',stimframeshift);

end