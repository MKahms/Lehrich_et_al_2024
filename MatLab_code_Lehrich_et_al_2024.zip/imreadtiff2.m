function [A]=imreadtiff2(dirname,fname,calcdirname)
% IMREADTIFF2 This function saves a MatLab image stack to a tiff stack

% dirname:      path of the directory, where the file of interest is saved
% calcdirname:  path of directory, where the calculation functions are saved
% fname:        name of the file of interest

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

tic
cd(dirname);
info = imfinfo(fname);
num_images = numel(info);
A=zeros(info(1,1).Height,info(1,1).Width,num_images,'double');%'uint16');

for k = 1:num_images
  A(:,:,k) = imread(fname,k,'Info', info);  

end
cd(calcdirname); %go back to the functions directory
toc