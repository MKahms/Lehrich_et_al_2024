function [kymograph, kymographdIdr, radiusFWHM, Diffconst, Diffconstpatch, cuti_high, inti_high, wavelet, waveletfilt, Diffconstwavelet, Cxval, Cyval, Int3, Int5, Int7, Int7_3ring, Int9_5ring, numpx3, numpx5, numpx7, numpx7_3ring, numpx9_5ring] = radialkymograph_small(ResultSNR13sort_5211_high,Astim,cutsize,pxsize)
% RADIALKYMOGRAPH plots radial kymograph around event

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024
%% generate templates for rings
Ymat=ones(cutsize);
Xmat=ones(cutsize);
for i=1:cutsize
    Ymat(:,i)=i*Ymat(:,i);
    Xmat(i,:)=i*Xmat(i,:);
end

h3=zeros(cutsize,cutsize);
h3(floor(cutsize/2):ceil(cutsize/2)+1,floor(cutsize/2):ceil(cutsize/2)+1)=1;
h3_ring=h3;
numpx3=sum(sum(h3_ring));

h5=zeros(cutsize,cutsize);
h52 = fspecial('disk', 2.5); h52=h52./max(max(h52)); h52=im2bw(h52,0.76);
h5(floor(cutsize/2)-1:ceil(cutsize/2)+2,floor(cutsize/2)-1:ceil(cutsize/2)+2)=h52;
h5_ring=h5-h3;
numpx5=sum(sum(h5_ring));

h7_ring=[];
numpx7=[];
numpx7_3ring=[];
h7_3ring=[];
if cutsize >= 7
h7=zeros(cutsize,cutsize);
h72 = fspecial('disk', 3.5); h72=h72./max(max(h72)); h72=im2bw(h72,0.84);
h7(floor(cutsize/2)-2:ceil(cutsize/2)+3,floor(cutsize/2)-2:ceil(cutsize/2)+3)=h72;
h7_ring=h7-h5;
h7_3ring=h7-h3;
numpx7=sum(sum(h7_ring));
numpx7_3ring=sum(sum(h7_3ring));
end

h9_ring=[];
numpx9=[];
numpx9_5ring=[];
h9_5ring=[];
if cutsize >= 9
h9=zeros(cutsize,cutsize);
h92 = fspecial('disk', 4.5); h92=h92./max(max(h92)); h92=im2bw(h92,0.79);
h9(floor(cutsize/2)-3:ceil(cutsize/2)+4,floor(cutsize/2)-3:ceil(cutsize/2)+4)=h92;
h9_ring=h9-h7;
h9_5ring=h9-h5;
numpx9=sum(sum(h9_ring));
numpx9_5ring=sum(sum(h9_5ring));
end

%% get data
framesstim=size(Astim,3);

cuti_high=zeros(cutsize,cutsize,framesstim,size(ResultSNR13sort_5211_high,2));
inti_high=zeros(framesstim,size(ResultSNR13sort_5211_high,2));
Cxval=zeros(framesstim,size(ResultSNR13sort_5211_high,2));
Cyval=zeros(framesstim,size(ResultSNR13sort_5211_high,2));

for i=1:size(ResultSNR13sort_5211_high,2)
    if round(ResultSNR13sort_5211_high(3,i))-(floor(cutsize/2))>=1 && round(ResultSNR13sort_5211_high(3,i))+(floor(cutsize/2))<=size(Astim,1) && round(ResultSNR13sort_5211_high(2,i))-(floor(cutsize/2))>=1 && round(ResultSNR13sort_5211_high(2,i))+(floor(cutsize/2))<=size(Astim,2)
    cuti_high(:,:,:,i)=Astim(round(ResultSNR13sort_5211_high(3,i))-(floor(cutsize/2)):round(ResultSNR13sort_5211_high(3,i))+(floor(cutsize/2)),round(ResultSNR13sort_5211_high(2,i))-(floor(cutsize/2)):round(ResultSNR13sort_5211_high(2,i))+(floor(cutsize/2)),:,ResultSNR13sort_5211_high(4,i));   
for j=1:framesstim
    if cutsize < 9
        Image=zeros(9,9);
        Image((((9-cutsize)/2)+1):(cutsize+(9-cutsize)/2),(((9-cutsize)/2)+1):(cutsize+(9-cutsize)/2))=cuti_high(:,:,j,i);
    else
        Image=cuti_high(:,:,j,i);
    end
    wavelet(:,:,j,i) = atrouswavelet_GUI(Image);
    if cutsize < 9
        Test=wavelet((((9-cutsize)/2)+1):(cutsize+(9-cutsize)/2),(((9-cutsize)/2)+1):(cutsize+(9-cutsize)/2),j,i);
    else
        Test=wavelet(:,:,j,i);
    end
    Test=mat2gray(Test);
    Testmask=imbinarize(Test);
    Test=Testmask.*Test;
    Cxval(j,i)=(sum(sum(Xmat.*Test))/sum(sum(Test)))-ceil(cutsize/2);
    Cyval(j,i)=(sum(sum(Ymat.*Test))/sum(sum(Test)))-ceil(cutsize/2);
    if round(ResultSNR13sort_5211_high(3,i))+round(Cxval(j,i))-(floor(cutsize/2)) >= 1 && round(ResultSNR13sort_5211_high(3,i))+round(Cxval(j,i))+(floor(cutsize/2)) <= size(Astim,1) && round(ResultSNR13sort_5211_high(2,i))+round(Cyval(j,i))-(floor(cutsize/2)) >=1 && round(ResultSNR13sort_5211_high(2,i))+round(Cyval(j,i))+(floor(cutsize/2)) <= size(Astim,2)
        cuti_high(:,:,j,i)=Astim(round(ResultSNR13sort_5211_high(3,i))+round(Cxval(j,i))-(floor(cutsize/2)):round(ResultSNR13sort_5211_high(3,i))+round(Cxval(j,i))+(floor(cutsize/2)),round(ResultSNR13sort_5211_high(2,i))+round(Cyval(j,i))-(floor(cutsize/2)):round(ResultSNR13sort_5211_high(2,i))+round(Cyval(j,i))+(floor(cutsize/2)),j,ResultSNR13sort_5211_high(4,i));
        inti_high(j,i)=sum(sum(cuti_high(:,:,j,i)));
    end
    if j==1
        sigma2(i)=mad(reshape(wavelet(:,:,j,i),1,(size(wavelet(:,:,j,i),1)*size(wavelet(:,:,j,i),2))),1)/0.67;
    end
    W=wavelet(:,:,j,i);
    W(W<=(1.5*sigma2(i)))=0;
    W(W>0)=1;
    waveletfilt(:,:,j,i)=W;
end
    end
end

for s=1:size(Cxval,2)
q=polyfit(10:10:100,(((pxsize./1000))^2.*((Cxval(6:15,s)).^2 + (Cyval(6:15,s)).^2))',1);
Diffconstpatch(s)=(1000.*q(1))/4; %in �m�/s
end

waveletarea=squeeze(sum(sum(waveletfilt,1),2));
waveletradius=(waveletarea.*((pxsize./1000).^2))./pi;
for i=1:size(waveletradius,2)
a=polyfit(10:10:50,waveletradius(6:10,i)',1);
Diffconstwavelet(i)=(1000.*a(1))/4;
end
%% apply rings on data
Int3=zeros(size(cuti_high,3),size(cuti_high,4));
Int5=zeros(size(cuti_high,3),size(cuti_high,4));
Int7=zeros(size(cuti_high,3),size(cuti_high,4));
Int3_ring=zeros(size(cuti_high,3),size(cuti_high,4));
Int5_ring=zeros(size(cuti_high,3),size(cuti_high,4));
Int7_ring=zeros(size(cuti_high,3),size(cuti_high,4));
Int7_3ring=zeros(size(cuti_high,3),size(cuti_high,4));
Int9_ring=zeros(size(cuti_high,3),size(cuti_high,4));
Int9_5ring=zeros(size(cuti_high,3),size(cuti_high,4));
for i=1:size(cuti_high,3)
    for j=1:size(cuti_high,4)
        Int3(i,j)=sum(sum(cuti_high(:,:,i,j).*h3));
        Int5(i,j)=sum(sum(cuti_high(:,:,i,j).*h5));
        Int3_ring(i,j)=sum(sum(cuti_high(:,:,i,j).*h3_ring));
        Int5_ring(i,j)=sum(sum(cuti_high(:,:,i,j).*h5_ring));
        if cutsize >= 7
        Int7(i,j)=sum(sum(cuti_high(:,:,i,j).*h7));
        Int7_ring(i,j)=sum(sum(cuti_high(:,:,i,j).*h7_ring));
        Int7_3ring(i,j)=sum(sum(cuti_high(:,:,i,j).*h7_3ring));
        end
        if cutsize >= 9
        Int9_ring(i,j)=sum(sum(cuti_high(:,:,i,j).*h9_ring));
        Int9_5ring(i,j)=sum(sum(cuti_high(:,:,i,j).*h9_5ring));
        end
    end
end

if cutsize == 7
siz=3;
end
if cutsize == 9
siz=4;
end

kymograph=zeros(siz,size(cuti_high,3),size(cuti_high,4));
kymographdIdr=zeros(siz,size(cuti_high,3),size(cuti_high,4));
for l=1:size(cuti_high,4)
    for k=1:size(cuti_high,3)
kymograph(1,k,l)=Int3_ring(k,l);
kymograph(2,k,l)=Int5_ring(k,l);
if cutsize >= 7
kymograph(3,k,l)=Int7_ring(k,l);
end
if cutsize >= 9
kymograph(4,k,l)=Int9_ring(k,l);
end

kymographdIdr(1,k,l)=Int3_ring(k,l)./numpx3;
kymographdIdr(2,k,l)=Int5_ring(k,l)./numpx5;
if cutsize >= 7
kymographdIdr(3,k,l)=Int7_ring(k,l)./numpx7;
end
if cutsize >= 9
kymographdIdr(4,k,l)=Int9_ring(k,l)./numpx9;
end
    end
end

oldopts=optimset('lsqcurvefit');
options=optimset(oldopts,'display','off','MaxIter',10000,'MaxFunEvals',10000,'algorithm','trust-region-reflective');%'levenberg-marquardt');

if cutsize == 7
h = waitbar(0,'computing fit...');
for i=1:size(kymographdIdr,3)
    waitbar(i / size(kymographdIdr,3))
    for j=6:15
        x0start(1)=kymographdIdr(1,j,i);
        x0start(2)=3;
        x0start(3)=1;
        lb=[max(max(kymographdIdr(:,j,i),1))*0.9 1 0]; %vector of lower bounds
        ub=[max(max(kymographdIdr(:,j,i),1)) 10 10]; %vector of lower bounds
        [x,resnorm,residual,exitflag,output]=lsqnonlin(@myfunrational_tiny,x0start,lb,ub,options,size(kymographdIdr,1),kymographdIdr(:,j,i));
        x(2)=(x(2)+0.5);
        radiusFWHM(:,j,i)=x;
    end
end
close(h)
for i=1:size(radiusFWHM,3)
a=polyfit(60:10:150,((pxsize./1000).*radiusFWHM(2,6:15,i)).^2,1);
Diffconst(i)=(1000.*a(1))/(4.*log(2)); %in �m�/s
end
end

if cutsize == 9
    h = waitbar(0,'computing fit...');
    for i=1:size(kymographdIdr,3)
        waitbar(i / size(kymographdIdr,3))
        for j=6:15
            x0start(1)=kymographdIdr(1,j,i);
            x0start(2)=3;
            x0start(3)=1;
            x0start(4)=1;
            lb=[max(max(kymographdIdr(:,j,i),1))*0.9 1 0 0];
            ub=[max(max(kymographdIdr(:,j,i),1)) 10 10 10];
            [x,resnorm,residual,exitflag,output]=lsqnonlin(@myfunrational_small,x0start,lb,ub,options,size(kymographdIdr,1),kymographdIdr(:,j,i));
            x(2)=(x(2)+0.5);
            radiusFWHM(:,j,i)=x;
        end
    end
    close(h)
    for i=1:size(radiusFWHM,3)
        a=polyfit(60:10:150,((pxsize./1000).*radiusFWHM(2,6:15,i)).^2,1);
        Diffconst(i)=(1000.*a(1))/(4.*log(2)); %in �m�/s
    end
end

end